/*
  Reusable Oracle SQL query: generate personalised interview slots.

  Required bind variables:
    :interviewerSid   VARCHAR2
    :oracleCandId     VARCHAR2
    :selectedDate     VARCHAR2 in YYYY-MM-DD format (interviewer's local date)
    :durationMinutes  NUMBER (e.g. 30, 45, 60, 120)
    :slotStepMinutes  NUMBER (e.g. 30, 45, 60, 120)

  The application resolves interviewer identifiers from interviewRequestId,
  then supplies them as bind values. This query only evaluates preferences.
*/
WITH
params AS (
    SELECT
        :interviewerSid AS INTERVIEWER_SID,
        :oracleCandId AS ORACLE_CAND_ID,
        TO_DATE(:selectedDate, 'YYYY-MM-DD') AS SELECTED_DATE,
        :durationMinutes AS DURATION_MINUTES,
        :slotStepMinutes AS SLOT_STEP_MINUTES,
        (TRUNC(TO_DATE(:selectedDate, 'YYYY-MM-DD'))
             - TRUNC(TO_DATE(:selectedDate, 'YYYY-MM-DD'), 'IW') + 1)
            AS DAY_OF_WEEK
    FROM DUAL
),
day_rules AS (
    SELECT s.DAY_OF_WEEK, s.START_MINUTE, s.END_MINUTE, s.IS_AVAILABLE
    FROM INTERVIEWER_PREFERENCE_SLOT s
    CROSS JOIN params p
    WHERE s.INTERVIEWER_SID = p.INTERVIEWER_SID
      AND s.ORACLE_CAND_ID = p.ORACLE_CAND_ID
      AND s.DAY_OF_WEEK = p.DAY_OF_WEEK
),
available_ordered AS (
    SELECT
        START_MINUTE,
        END_MINUTE,
        MAX(END_MINUTE) OVER (
            ORDER BY START_MINUTE, END_MINUTE
            ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING
        ) AS PRIOR_MAX_END
    FROM day_rules
    WHERE IS_AVAILABLE = 1
),
available_marked AS (
    SELECT
        START_MINUTE,
        END_MINUTE,
        CASE
            WHEN PRIOR_MAX_END IS NULL OR START_MINUTE > PRIOR_MAX_END THEN 1
            ELSE 0
        END AS NEW_GROUP
    FROM available_ordered
),
available_grouped AS (
    SELECT
        START_MINUTE,
        END_MINUTE,
        SUM(NEW_GROUP) OVER (
            ORDER BY START_MINUTE, END_MINUTE
            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
        ) AS GROUP_ID
    FROM available_marked
),
merged_available AS (
    SELECT
        GROUP_ID AS WINDOW_ID,
        MIN(START_MINUTE) AS WINDOW_START,
        MAX(END_MINUTE) AS WINDOW_END
    FROM available_grouped
    GROUP BY GROUP_ID
),
boundaries AS (
    SELECT WINDOW_ID, WINDOW_START AS BOUNDARY_MINUTE
    FROM merged_available
    UNION
    SELECT WINDOW_ID, WINDOW_END AS BOUNDARY_MINUTE
    FROM merged_available
    UNION
    SELECT
        a.WINDOW_ID,
        GREATEST(a.WINDOW_START, b.START_MINUTE) AS BOUNDARY_MINUTE
    FROM merged_available a
    JOIN day_rules b
      ON b.IS_AVAILABLE = 0
     AND b.END_MINUTE > a.WINDOW_START
     AND b.START_MINUTE < a.WINDOW_END
    UNION
    SELECT
        a.WINDOW_ID,
        LEAST(a.WINDOW_END, b.END_MINUTE) AS BOUNDARY_MINUTE
    FROM merged_available a
    JOIN day_rules b
      ON b.IS_AVAILABLE = 0
     AND b.END_MINUTE > a.WINDOW_START
     AND b.START_MINUTE < a.WINDOW_END
),
segments_ordered AS (
    SELECT
        WINDOW_ID,
        BOUNDARY_MINUTE AS SEGMENT_START,
        LEAD(BOUNDARY_MINUTE) OVER (
            PARTITION BY WINDOW_ID
            ORDER BY BOUNDARY_MINUTE
        ) AS SEGMENT_END
    FROM boundaries
),
effective_segments AS (
    SELECT s.WINDOW_ID, s.SEGMENT_START, s.SEGMENT_END
    FROM segments_ordered s
    WHERE s.SEGMENT_END IS NOT NULL
      AND s.SEGMENT_END > s.SEGMENT_START
      AND NOT EXISTS (
          SELECT 1
          FROM day_rules b
          WHERE b.IS_AVAILABLE = 0
            AND b.START_MINUTE < s.SEGMENT_END
            AND b.END_MINUTE > s.SEGMENT_START
      )
),
numbers AS (
    SELECT LEVEL - 1 AS N
    FROM DUAL
    CONNECT BY LEVEL <= 1440
),
generated_slots AS (
    SELECT
        p.SELECTED_DATE,
        s.SEGMENT_START + (n.N * p.SLOT_STEP_MINUTES) AS SLOT_START_MINUTE,
        s.SEGMENT_START + (n.N * p.SLOT_STEP_MINUTES)
            + p.DURATION_MINUTES AS SLOT_END_MINUTE
    FROM params p
    CROSS JOIN effective_segments s
    CROSS JOIN numbers n
    WHERE p.DURATION_MINUTES > 0
      AND p.SLOT_STEP_MINUTES > 0
      AND s.SEGMENT_START + (n.N * p.SLOT_STEP_MINUTES)
            + p.DURATION_MINUTES <= s.SEGMENT_END
)
SELECT
    TO_CHAR(TRUNC(SELECTED_DATE) + SLOT_START_MINUTE / 1440,
            'YYYY-MM-DD HH:MI AM') AS SLOT_START,
    TO_CHAR(TRUNC(SELECTED_DATE) + SLOT_END_MINUTE / 1440,
            'YYYY-MM-DD HH:MI AM') AS SLOT_END,
    SLOT_START_MINUTE,
    SLOT_END_MINUTE
FROM generated_slots
ORDER BY SLOT_START_MINUTE;
