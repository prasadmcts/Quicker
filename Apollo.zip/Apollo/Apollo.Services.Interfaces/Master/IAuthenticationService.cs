﻿using Apollo.Services.Models.Communication;
using System.Threading.Tasks;

namespace Apollo.Services.Interfaces.Master
{
    public interface IAuthenticationService
    {
        Task<TokenResponse> CreateAccessTokenAsync(string email, string password);
        Task<TokenResponse> RefreshTokenAsync(string refreshToken, string userEmail);
        void RevokeRefreshToken(string refreshToken);
    }
}
