﻿using Apollo.Common.Enums;
using Apollo.Data.Models.Master.Auth;
using Apollo.Services.Models.Communication;
using System.Threading.Tasks;

namespace Apollo.Services.Interfaces.Master
{
    public interface IUserService
    {
        Task<CreateUserResponse> CreateUserAsync(User user, params ERole[] userRoles);
        Task<User> FindByEmailAsync(string email);
    }
}
