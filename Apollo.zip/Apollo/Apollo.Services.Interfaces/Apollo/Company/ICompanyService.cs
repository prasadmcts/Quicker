﻿namespace Apollo.Services.Interfaces.Apollo.Company
{
    public interface ICompanyService
    {
        IEmployeeService EmployeeService { get; set; }
        IEmployerService EmployerService { get; set; }
    }
}