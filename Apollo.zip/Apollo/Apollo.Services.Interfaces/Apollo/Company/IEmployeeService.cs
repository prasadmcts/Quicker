﻿using Apollo.Services.Models.Apollo.Company;
using Apollo.Services.Models.Communication;
using Apollo.Services.Models.Queries;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Apollo.Services.Interfaces.Apollo.Company
{
    //public interface IEmployeeService<TDataModel, TEntity> : IBaseService<TDataModel, TEntity> where TEntity : class where TDataModel : class
    //{
    //}

    public interface IEmployeeService
    {
        Task<IEnumerable<EmployeeModel>> ListAsync();
        Task<QueryResult<EmployeeModel>> ListAsync(EmployeeQuery query);
        Task<CommonResponse<EmployeeModel>> SaveAsync(EmployeeModel employeeModel);
        Task<EmployeeResponse> UpdateAsync(Guid id, EmployeeModel employee);
        Task<EmployeeResponse> DeleteAsync(Guid id);
    }
}
