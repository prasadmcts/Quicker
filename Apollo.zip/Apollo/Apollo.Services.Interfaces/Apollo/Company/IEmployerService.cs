﻿using Apollo.Services.Models.Apollo.Company;
using Apollo.Services.Models.Communication;
using Apollo.Services.Models.Queries;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Apollo.Services.Interfaces.Apollo.Company
{
    public interface IEmployerService
    {
        Task<IEnumerable<EmployerModel>> ListAsync();
        Task<QueryResult<EmployerModel>> ListAsync(EmployerQuery query);
        Task<EmployerResponse> SaveAsync(EmployerModel employer);
        Task<EmployerResponse> UpdateAsync(Guid id, EmployerModel employer);
        Task<EmployerResponse> DeleteAsync(Guid id);
    }
}
