﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Apollo.Services.Interfaces
{
    //public interface IBaseService<TDataModel, TEntity> : IDisposable where TDataModel : class where TEntity : class
    //{
    //    Task Create(TDataModel model);

    //    Task Delete(Guid id);

    //    Task<IList<TDataModel>> GetAll();

    //    Task<TDataModel> GetById(Guid id);

    //    Task Save(TDataModel entity);

    //    Task Update(Guid id, TDataModel model);
    //}

    public interface IBaseService<TDataModel, TEntity> : IDisposable where TDataModel : class where TEntity : class
    {
        Task Create(TDataModel model);

        Task Delete(Guid id);

        Task<IList<TDataModel>> GetAll();

        Task<TDataModel> GetById(Guid id);

        Task Save(TDataModel entity);

        Task Update(Guid id, TDataModel model);
    }
}
