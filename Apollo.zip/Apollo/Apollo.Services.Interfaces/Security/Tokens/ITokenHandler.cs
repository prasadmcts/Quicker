﻿using Apollo.Data.Models.Master.Auth;
using Apollo.Services.Models.Communication.Security.Tokens;

namespace Apollo.Services.Interfaces.Security.Tokens
{
    public interface ITokenHandler
    {
        AccessToken CreateAccessToken(User user);
        RefreshToken TakeRefreshToken(string token);
        void RevokeRefreshToken(string token);
    }
}
