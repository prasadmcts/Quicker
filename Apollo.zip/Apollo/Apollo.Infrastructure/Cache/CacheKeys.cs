namespace Apollo.Common.Cache
{
    public enum CacheKeys
    {
        CategoriesList,
        ProductsList,
    }
}