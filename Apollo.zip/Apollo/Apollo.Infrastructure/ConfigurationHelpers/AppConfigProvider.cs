﻿using Apollo.Common.Constants;
using Apollo.Common.Model;
using Microsoft.Extensions.Configuration;
using System;
using System.Net.Mail;

namespace Apollo.Infrastructure.ConfigurationHelpers
{
    public class AppConfigProvider
    {
        private readonly IConfiguration _configuration;
        private readonly IConfigurationSection _appConfig;
        private readonly IConfigurationSection _mailSettings;

        public AppConfigProvider(IConfiguration configuration)
        {
            _configuration = configuration;
            _appConfig = _configuration.GetSection(ConfiguarionConstants.AppConfiguration);
            _mailSettings = _configuration.GetSection(ConfiguarionConstants.MailSettings);
        }

        public MailSettings MailSettings => new MailSettings
        {
            SmtpHost = GetAppSetting<string>(_mailSettings, ConfiguarionConstants.SmtpHost),
            SmtpPort = GetAppSetting<int>(_mailSettings, ConfiguarionConstants.SmtpPort),
            SmtpEnableSsl = GetAppSetting<bool>(_mailSettings, ConfiguarionConstants.SmtpEnableSsl),
            SmtpFrom = GetAppSetting<string>(_mailSettings, ConfiguarionConstants.SmtpFrom),
            SmtpDeliveryMethod = GetAppSetting<SmtpDeliveryMethod>(_mailSettings, ConfiguarionConstants.SmtpDeliveryMethod, SmtpDeliveryMethod.SpecifiedPickupDirectory),
            SmtpSpecifiedPickupDirectoryLocation = GetAppSetting<string>(_mailSettings, ConfiguarionConstants.SmtpSpecifiedPickupDirectoryLocation)
        };

        public string Key => GetAppSetting<string>(_appConfig, ConfiguarionConstants.Key);

        public string LogPath => GetAppSetting<string>(_appConfig, ConfiguarionConstants.LogsPath);

        #region Private Methods

        private T GetAppSetting<T>(IConfigurationSection section, string key, T defaultValue = default) => GetAppSetting(section, key, defaultValue, false);

        private T GetAppSetting<T>(IConfigurationSection section, string key, T defaultValue, bool throwExceptions)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(key))
                {
                    string value = section[key];

                    if (value != null)
                    {
                        var theType = typeof(T);
                        if (theType.IsEnum)
                            return (T)Enum.Parse(theType, value.ToString(), true);
                        return (T)Convert.ChangeType(value, theType);
                    }
                    return default;
                }
            }
            catch
            {
                if (throwExceptions)
                    throw;
            }
            return defaultValue;
        }

        #endregion
    }
}