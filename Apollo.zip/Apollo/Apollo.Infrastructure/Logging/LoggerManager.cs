﻿using NLog;

namespace Apollo.Infrastructure.Logging
{
    public class LoggerManager : ILoggerManager
    {
        private static ILogger logger = LogManager.GetCurrentClassLogger();

        public LoggerManager()
        {
        }

        public void LogDebug(string message)
        {
            logger.Debug(message);
        }

        public void LogError(string message)
        {
            logger.Error(message);
        }

        public void LogInfo(string message)
        {
            logger.Info(message);
        }

        public void LogWarn(string message)
        {
            logger.Warn(message);
        }
    }

    //public class LoggerManager : ILoggerManager
    //{
    //    private readonly AppConfigProvider _appConfigProvider;
    //    private ConcurrentDictionary<string, Logger> _loggers;

    //    public LoggerManager(AppConfigProvider appConfigProvider)
    //    {
    //        this._appConfigProvider = appConfigProvider;
    //        this._loggers = new ConcurrentDictionary<string, Logger>();
    //    }

    //    public void Log(string message, int customerId = 0)
    //    {
    //        var logger = Initialize(customerId.ToString());
    //        logger.Info(message);
    //    }

    //    private Logger Initialize(string instanceName)
    //    {
    //        var target = new FileTarget
    //        {
    //            Name = instanceName,
    //            FileName = $@"{$"{_appConfigProvider.LogPath}\\{instanceName}"}\\${{shortdate}}.log",
    //            Layout = "${date:format=HH\\:MM\\:ss} ${logger} ${message}"
    //        };

    //        var config = new LoggingConfiguration();
    //        config.AddTarget(instanceName, target);

    //        var rule = new LoggingRule("*", LogLevel.Info, target);
    //        config.LoggingRules.Add(rule);

    //        //Have to initialize this everytime b/c it retains the last initialized configuration and we need to reset it.
    //        LogManager.Configuration = config;
    //        return _loggers.GetOrAdd(instanceName, LogManager.GetLogger(instanceName));
    //    }
    //}
}
