﻿using Apollo.Data.Models.Master.Auth;

namespace Apollo.Services.Models.Communication
{
    public class CreateUserResponse : BaseResponse<User>
    {
        public CreateUserResponse(User user) : base(user) { }

        public CreateUserResponse(string message) : base(message) { }
    }
}
