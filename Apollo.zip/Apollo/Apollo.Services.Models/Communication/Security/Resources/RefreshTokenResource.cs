namespace Apollo.Services.Models.Communication.Security.Resources
{
    public class RefreshTokenResource
    {
        public string Token { get; set; }

        public string UserEmail { get; set; }
    }
}