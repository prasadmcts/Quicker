namespace Apollo.Services.Models.Communication.Security.Resources
{
    public class RevokeTokenResource
    {
        public string Token { get; set; }
    }
}