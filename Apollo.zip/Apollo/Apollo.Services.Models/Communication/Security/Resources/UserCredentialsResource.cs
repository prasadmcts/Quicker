namespace Apollo.Services.Models.Communication.Security.Resources
{
    public class UserCredentialsResource
    {
        public string Email { get; set; }

        public string Password { get; set; }
    }
}