using System;
using System.Collections.Generic;

namespace Apollo.Services.Models.Communication.Security.Resources
{
    public class UserResource
    {
        public Guid Id { get; set; }
        public string Email { get; set; }
        public IEnumerable<string> Roles { get; set; }
    }
}