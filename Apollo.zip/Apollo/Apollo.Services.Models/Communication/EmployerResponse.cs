using Apollo.Services.Models.Apollo.Company;

namespace Apollo.Services.Models.Communication
{
    public class EmployerResponse : BaseResponse<EmployerModel>
    {
        public EmployerResponse(EmployerModel employer) : base(employer) { }

        public EmployerResponse(string message) : base(message) { }
    }
}