﻿using Apollo.Services.Models.Communication.Security.Tokens;

namespace Apollo.Services.Models.Communication
{
    public class TokenResponse : BaseResponse<AccessToken>
    {
        public TokenResponse(AccessToken token) : base(token) { }

        public TokenResponse(string message) : base(message) { }
    }
}
