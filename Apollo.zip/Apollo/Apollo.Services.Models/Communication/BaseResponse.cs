namespace Apollo.Services.Models.Communication
{
    public abstract class BaseResponse<T>
    {
        public bool Success { get; private set; }
        public string Message { get; private set; }
        public T Resource { get; private set; }

        protected BaseResponse(T resource)
        {
            Success = true;
            Message = string.Empty;
            Resource = resource;
        }

        protected BaseResponse(string message)
        {
            Success = false;
            Message = message;
            Resource = default;
        }
    }

    public class CommonResponse<TEntity> : BaseResponse<TEntity> where TEntity : class
    {
        /// <summary>
        /// Creates a success response.
        /// </summary>
        /// <param name="entity">Saved category.</param>
        /// <returns>Response.</returns>
        public CommonResponse(TEntity entity) : base(entity)
        { }

        /// <summary>
        /// Creates am error response.
        /// </summary>
        /// <param name="message">Error message.</param>
        /// <returns>Response.</returns>
        public CommonResponse(string message) : base(message) { }
    }
}