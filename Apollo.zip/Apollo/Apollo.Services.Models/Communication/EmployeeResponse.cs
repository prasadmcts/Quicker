using Apollo.Services.Models.Apollo.Company;

namespace Apollo.Services.Models.Communication
{
    public class EmployeeResponse : BaseResponse<EmployeeModel>
    {
        public EmployeeResponse(EmployeeModel employee) : base(employee) { }

        public EmployeeResponse(string message) : base(message) { }
    }
}