﻿using Apollo.Data.Models.Apollo.Company;
using Apollo.Services.Models.Apollo.Company;
using AutoMapper;
using System.Collections.Generic;

namespace Apollo.Services.Models
{
    public class ModelFactory
    {
        private readonly IMapper _mapper;

        public ModelFactory(IMapper mapper)
        {
            _mapper = mapper;
        }

        #region Employee

        public Employee Create(EmployeeModel employee)
        {
            return _mapper.Map<EmployeeModel, Employee>(employee);
        }

        public EmployeeModel Create(Employee employee)
        {
            return _mapper.Map<Employee, EmployeeModel>(employee);
        }

        public List<EmployeeModel> Create(List<Employee> employers)
        {
            return _mapper.Map<List<Employee>, List<EmployeeModel>>(employers);
        }

        #endregion
    }

    //public class ModelFactory<TDataModel, TEntity> where TDataModel : class where TEntity : class
    //{
    //    public TEntity Create(TDataModel model)
    //    {
    //        return _mapper.Map<TDataModel, TEntity>(model);
    //    }

    //    public IList<TEntity> Create(IList<TDataModel> lstModel)
    //    {
    //        return _mapper.Map<IList<TDataModel>, IList<TEntity>>(lstModel);
    //    }

    //    public TDataModel Create(TEntity entity)
    //    {
    //        return _mapper.Map<TEntity, TDataModel>(entity);
    //    }

    //    public IList<TDataModel> Create(IList<TEntity> lstEntity)
    //    {
    //        return _mapper.Map<IList<TEntity>, IList<TDataModel>>(lstEntity);
    //    }
    //}
}
