﻿using Apollo.Common.Model;
using System;

namespace Apollo.Services.Models
{
    public abstract class BaseModel<TIdT> : IAuditable
    {
        public TIdT Id { get; set; }

        public string CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public string ModifiedBy { get; set; }

        public DateTime? ModifiedDate { get; set; }
    }
}
