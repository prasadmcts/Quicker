﻿using Apollo.Common.Constants;
using Apollo.Services.Models.Apollo.Company;
using FluentValidation;

namespace Apollo.Services.Models.ApolloValidators
{
    public class EmployeeModelValidators : AbstractValidator<EmployeeModel>
    {
        public EmployeeModelValidators()
        {
            RuleFor(x => x.Name).NotEmpty().WithMessage($"{nameof(EmployeeModel.Name)} {CommonConstants.IsMandatory}");
            RuleFor(x => x.Pin).NotEmpty().Must(x => x > 0).WithMessage($"{nameof(EmployeeModel.Pin)} {CommonConstants.IsMandatory}");
        }
    }
}
