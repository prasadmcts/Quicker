﻿using System;

namespace Apollo.Services.Models.Apollo.Company
{
    public class EmployerModel : BaseModel<Guid>
    {
        public string Name { get; set; }
        public bool Active { get; set; }
        public int Pin { get; set; }
    }
}