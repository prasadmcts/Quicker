using Apollo.Common.Constants;
using Apollo.Services.Models.Communication.Security.Resources;
using FluentValidation;

namespace Apollo.Services.Models.CommunicationValidators.Security.Resources
{
    public class UserCredentialsResourceValidators : AbstractValidator<UserCredentialsResource>
    {
        public UserCredentialsResourceValidators()
        {
            RuleFor(x => x.Email).NotEmpty().WithMessage($"{nameof(UserCredentialsResource.Email)} {CommonConstants.IsMandatory}").MaximumLength(CommonConstants.Length255).EmailAddress();
            RuleFor(x => x.Password).NotEmpty().WithMessage($"{nameof(UserCredentialsResource.Password)} {CommonConstants.IsMandatory}").MaximumLength(CommonConstants.Length32);
        }
    }
}