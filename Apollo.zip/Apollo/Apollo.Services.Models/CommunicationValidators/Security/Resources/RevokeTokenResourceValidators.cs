using Apollo.Common.Constants;
using Apollo.Services.Models.Communication.Security.Resources;
using FluentValidation;

namespace Apollo.Services.Models.CommunicationValidators.Security.Resources
{
    public class RevokeTokenResourceValidators : AbstractValidator<RevokeTokenResource>
    {
        public RevokeTokenResourceValidators()
        {
            RuleFor(x => x.Token).NotEmpty().WithMessage($"{nameof(RevokeTokenResource.Token)} {CommonConstants.IsMandatory}");
        }
    }
}