using Apollo.Common.Constants;
using Apollo.Services.Models.Communication.Security.Resources;
using FluentValidation;

namespace Apollo.Services.Models.CommunicationValidators.Security.Resources
{
    public class RefreshTokenResourceValidators : AbstractValidator<RefreshTokenResource>
    {
        public RefreshTokenResourceValidators()
        {
            RuleFor(x => x.Token).NotEmpty().WithMessage($"{nameof(RefreshTokenResource.Token)} {CommonConstants.IsMandatory}");
            RuleFor(x => x.UserEmail).NotEmpty().MaximumLength(CommonConstants.Length255).EmailAddress().WithMessage($"{nameof(RefreshTokenResource.UserEmail)} {CommonConstants.IsMandatory}");
        }
    }
}