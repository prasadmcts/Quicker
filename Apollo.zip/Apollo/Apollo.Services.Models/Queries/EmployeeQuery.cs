using System;

namespace Apollo.Services.Models.Queries
{
    public class EmployeeQuery : Query
    {
        public Guid? Id { get; set; }

        public EmployeeQuery(Guid? id, int page, int itemsPerPage) : base(page, itemsPerPage)
        {
            Id = id;
        }
    }
}