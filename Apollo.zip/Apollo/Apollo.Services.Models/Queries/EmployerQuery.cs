using System;

namespace Apollo.Services.Models.Queries
{
    public class EmployerQuery : Query
    {
        public Guid? Id { get; set; }

        public EmployerQuery(Guid? id, int page, int itemsPerPage) : base(page, itemsPerPage)
        {
            Id = id;
        }
    }
}