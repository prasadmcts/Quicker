﻿using Apollo.Web.Api.Extensions;
using Apollo.Web.Api.Resources;
using Microsoft.AspNetCore.Mvc;

namespace Apollo.Web.Api.Config
{
    public static class InvalidModelStateResponseFactory
    {
        public static IActionResult ProduceErrorResponse(ActionContext context)
        {
            var errors = context.ModelState.GetErrorMessages();
            var response = new ErrorResource(messages: errors);

            return new BadRequestObjectResult(response);
        }
    }
}
