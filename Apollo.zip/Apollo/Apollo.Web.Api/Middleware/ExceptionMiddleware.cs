﻿using Apollo.Common.Constants;
using Apollo.Common.Exceptions;
using Apollo.Infrastructure.Logging;
using Apollo.Services.Models;
using Microsoft.AspNetCore.Http;
using System;
using System.Net;
using System.Threading.Tasks;

namespace Apollo.Web.Api.CustomExceptionMiddleware
{
    public class ExceptionMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILoggerManager _logger;

        public ExceptionMiddleware(RequestDelegate next, ILoggerManager logger)
        {
            _logger = logger;
            _next = next;
        }

        public async Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
                await _next(httpContext);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                await HandleExceptionAsync(httpContext, ex);
            }
        }

        private Task HandleExceptionAsync(HttpContext context, Exception ex)
        {
            var code = HttpStatusCode.InternalServerError; // 500 if unexpected
            var message = CommonConstants.InternalServer;

            if (ex is NotImplementedException) code = HttpStatusCode.NotFound;
            else if (ex is UnauthorizedAccessException) code = HttpStatusCode.Unauthorized;
            else if (ex is ApolloBusinessException) { code = HttpStatusCode.BadRequest; message = ex.Message; }
            else if (ex is ApolloDataException)  code = HttpStatusCode.BadRequest;
            else if (ex is ApolloException) code = HttpStatusCode.BadRequest;

            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)code;

            return context.Response.WriteAsync(new ErrorDetails
            {
                StatusCode = (int)code,
                Message = message
            }.ToString());
        }
    }
}