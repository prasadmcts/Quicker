﻿using Apollo.Data.Apollo.DbContexts;
using Apollo.Data.CommandQuery;
using Apollo.Data.CommandQuery.Apollo.Company;
using Apollo.Data.CommandQuery.Company;
using Apollo.Data.CommandQuery.Interfaces;
using Apollo.Data.CommandQuery.Interfaces.Apollo.Company;
using Apollo.Data.CommandQuery.Interfaces.Master.Auth;
using Apollo.Data.Master.DbContexts;
using Apollo.Infrastructure.ConfigurationHelpers;
using Apollo.Infrastructure.Logging;
using Apollo.Services.Apollo.Company;
using Apollo.Services.Interfaces.Apollo.Company;
using Apollo.Services.Interfaces.Master;
using Apollo.Services.Interfaces.Security.Hashing;
using Apollo.Services.Interfaces.Security.Tokens;
using Apollo.Services.Master;
using Apollo.Services.Models;
using Apollo.Services.Security.Hashing;
using Apollo.Services.Security.Tokens;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System;
using System.IO;
using System.Reflection;

namespace Apollo.Web.Api.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddDI(this IServiceCollection services)
        {
            services.AddUtilities();
            services.AddRepositories();
            services.AddServices();

            return services;
        }

        private static IServiceCollection AddUtilities(this IServiceCollection services)
        {
            services.AddSingleton<ILoggerManager, LoggerManager>();
            services.AddSingleton<ModelFactory>();
            services.AddSingleton<AppConfigProvider>();
            services.AddSingleton<IPasswordHasher, PasswordHasher>();
            services.AddSingleton<ITokenHandler, Services.Security.Tokens.TokenHandler>();

            return services;
        }

        private static IServiceCollection AddRepositories(this IServiceCollection services)
        {
            services.AddScoped<IEmployeeRepository, EmployeeRepository>();
            services.AddScoped<IEmployerRepository, EmployerRepository>();
            services.AddScoped<ICompanyRepository, CompanyRepository>();
            services.AddScoped<IUnitOfWork, UnitOfWork>();

            services.AddScoped<IUserRepository, UserRepository>();


            return services;
        }

        private static IServiceCollection AddServices(this IServiceCollection services)
        {
            services.AddScoped<IEmployerService, EmployerService>();
            services.AddScoped<IEmployeeService, EmployeeService>();
            services.AddScoped<ICompanyService, CompanyService>();

            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IAuthenticationService, AuthenticationService>();

            return services;
        }

        public static IServiceCollection AddDbContexts(this IServiceCollection services, IConfiguration Configuration)
        {
            services.AddScoped<ApolloContext>();
            services.AddDbContext<ApolloContext>(options =>
            {
                options.UseSqlServer(Configuration.GetSection("ConnectionStrings")["ApolloDatabase"]);
            });

            services.AddScoped<MasterContext>();
            services.AddDbContext<MasterContext>(options =>
            {
                options.UseSqlServer(Configuration.GetSection("ConnectionStrings")["MasterDatabase"]);
            });

            return services;
        }

        public static IServiceCollection AddAuthenticationSettings(this IServiceCollection services, IConfiguration Configuration)
        {
            var signingConfigurations = new SigningConfigurations();
            services.AddSingleton(signingConfigurations);

            services.Configure<TokenOptions>(Configuration.GetSection("TokenOptions"));
            var tokenOptions = Configuration.GetSection("TokenOptions").Get<TokenOptions>();

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(jwtBearerOptions =>
                {
                    jwtBearerOptions.TokenValidationParameters = new TokenValidationParameters()
                    {
                        ValidateAudience = true,
                        ValidateLifetime = true,
                        ValidateIssuerSigningKey = true,
                        ValidIssuer = tokenOptions.Issuer,
                        ValidAudience = tokenOptions.Audience,
                        IssuerSigningKey = signingConfigurations.Key,
                        ClockSkew = TimeSpan.Zero
                    };
                });

            return services;
        }

        public static IServiceCollection AddSwagger(this IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = "v1",
                    Title = "Apollo",
                    Description = "A simple example ASP.NET Core Web API",
                    TermsOfService = new Uri("https://github.com/prasadmcts"),
                    Contact = new OpenApiContact
                    {
                        Name = "Prasad Kanaparthi",
                        Email = "prasad.kanaparthi@anz.com",
                        Url = new Uri("https://in.linkedin.com/in/prasadkanaparthi"),
                    },
                    License = new OpenApiLicense
                    {
                        Name = "Use under LICX",
                        Url = new Uri("https://github.com/prasadmcts"),
                    }
                });

                // Set the comments path for the Swagger JSON and UI.
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                c.IncludeXmlComments(xmlPath);

                // c.ResolveConflictingActions(apiDescriptions => apiDescriptions.First());
            });

            return services;
        }
    }
}