﻿using Apollo.Web.Api.CustomExceptionMiddleware;
using Microsoft.AspNetCore.Builder;

namespace Apollo.Web.Api.Extensions
{
    public static class ExceptionMiddlewareExtensions
    {
        public static void ConfigureCustomExceptionMiddleware(this IApplicationBuilder app)
        {
            app.UseMiddleware<ExceptionMiddleware>();
        }
    }
}
