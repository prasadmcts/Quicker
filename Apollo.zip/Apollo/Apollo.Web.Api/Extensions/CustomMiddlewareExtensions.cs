﻿using Apollo.Web.Api.Middleware;
using Microsoft.AspNetCore.Builder;

namespace Apollo.Web.Api.Extensions
{
    public static class CustomMiddlewareExtensions
    {
        public static void ConfigureMiddleware(this IApplicationBuilder app)
        {
            //app.UseCorsMiddleware();
            app.ConfigureCustomExceptionMiddleware(); // or app.UseMiddleware<ExceptionMiddleware>();
            //app.UseMiddleware<ApiLoggingMiddleware>();
        }
    }
}
