﻿using Apollo.Web.Api.Middleware;
using Microsoft.AspNetCore.Builder;

namespace Apollo.Web.Api.Extensions
{
    public static class CorsMiddlewareExtensions
    {
        public static IApplicationBuilder UseCorsMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<CorsMiddleware>();
        }
    }
}
