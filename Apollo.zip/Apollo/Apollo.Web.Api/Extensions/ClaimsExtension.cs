﻿using Apollo.Common.Constants;
using System.ComponentModel;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Security.Principal;
using System.Web.Http;

namespace Apollo.Web.Api.Extensions
{
    public static class ClaimsExtension
    {
        public static string GetCurrentUserEmail(this IIdentity identity)
        {
            var user = (identity as ClaimsIdentity);
            return user.GetClaim<string>(CustomClaimTypes.Email);
        }

        public static T GetClaim<T>(this ClaimsIdentity identity, string claimType)
        {
            if (!identity.HasClaim(t => t.Type == claimType))
            {
                throw new HttpResponseException(HttpStatusCode.BadRequest);
            }

            var claim = identity.Claims.FirstOrDefault(c => c.Type == claimType);
            return (T)TypeDescriptor.GetConverter(typeof(T)).ConvertFromInvariantString(claim.Value);
        }

    }
}
