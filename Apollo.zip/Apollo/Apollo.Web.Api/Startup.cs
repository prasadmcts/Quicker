using Apollo.Services.Models.ApolloValidators;
using Apollo.Web.Api.ActionFilter;
using Apollo.Web.Api.Config;
using Apollo.Web.Api.Extensions;
using Apollo.Web.Api.Middleware;
using AutoMapper;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json.Serialization;
using NLog;
using System;
using System.IO;
using System.Reflection;

namespace Apollo.Web.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            LogManager.LoadConfiguration(string.Concat(Directory.GetCurrentDirectory(), "/nlog.config"));
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        /// configure service provider
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMemoryCache();

            services.AddControllers();

            services.AddSwagger();
            services.AddAuthenticationSettings(Configuration);
            services.AddDbContexts(Configuration);
            services.AddDI();

            services.AddAutoMapper(typeof(Startup));

            services.AddMvc(options =>
            {
                options.Filters.Add(new ProducesAttribute("application/json"));
                options.Filters.Add(typeof(ValidatorActionFilter));
                // options.Filters.Add(typeof(CustomExceptionFilter));
            })
            .SetCompatibilityVersion(CompatibilityVersion.Latest)
            .ConfigureApiBehaviorOptions(options =>
            {
                // Adds a custom error response factory when ModelState is invalid
                options.InvalidModelStateResponseFactory = InvalidModelStateResponseFactory.ProduceErrorResponse;
            })
            .AddFluentValidation(fv => {
                fv.RegisterValidatorsFromAssemblyContaining<EmployeeModelValidators>();
                // fv.ImplicitlyValidateChildProperties = true; // Note that if you enable this behaviour you should not use SetValidator for child properties, or the validator will be executed twice. (https://fluentvalidation.net/aspnet)
            })
            .AddNewtonsoftJson(options => options.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver());
        }

        // configure pipeline
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }

            app.ConfigureMiddleware();

            app.UseHttpsRedirection();

            app.UseRouting();
            
            app.UseAuthentication();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                this.CreateRoutes(endpoints);
                endpoints.MapControllers();
            });

            app.UseStaticFiles();

            // Enable middleware to serve generated Swagger as a JSON endpoint.
            app.UseSwagger();

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.), specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "My Apollo API V1");
            });
        }

        private void CreateRoutes(IEndpointRouteBuilder enpoints)
        {
            enpoints.MapControllerRoute("Default", "{controller=Root}/{action=Index}/{id?}");
        }
    }
}