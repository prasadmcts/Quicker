﻿using Microsoft.AspNetCore.Mvc;

namespace Apollo.Web.Api.Controllers
{
    public abstract class BaseApiController : ControllerBase
    {
    }
}
