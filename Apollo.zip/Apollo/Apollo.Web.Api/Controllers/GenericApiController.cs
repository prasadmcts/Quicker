﻿using Microsoft.AspNetCore.Mvc;

namespace Apollo.Web.Api.Controllers
{
    public class GenericApiController<TDataModel, TEntity> : BaseApiController where TEntity : class, new() where TDataModel : class, new()
    {
        [HttpGet]
        public ActionResult Get()
        {
            return Ok($"Prasad - All");
        }

        [HttpGet]
        [Route("{id}")]
        public ActionResult Get(int id)
        {
            return Ok($"The value is {id}");
        }

        [HttpPost]
        public ActionResult Post(TEntity entity)
        {
            return Ok($"Prasad - Success {entity}");
        }

        [HttpPut]
        public ActionResult Put(TEntity entity)
        {
            return Ok($"Prasad - Success {entity}");
        }

        [HttpDelete]
        [Route("{id}")]
        public ActionResult Delete(int id)
        {
            return Ok($"Prasad - Success {id}");
        }
    }
}