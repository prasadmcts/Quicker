﻿using Apollo.Infrastructure.Logging;
using Apollo.Services.Interfaces.Apollo.Company;
using Apollo.Services.Models.Apollo.Company;
using Apollo.Web.Api.Resources;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Apollo.Web.Api.Controllers
{
    //[Route("api/{controller}")]
    //[ApiController]
    //public class EmployeeController : GenericApiController<EmployeeModel, Employee>
    //{
    //}

    [Route("api/Employee")] // {controller} -- Swagger is not working
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly ILoggerManager _logger;
        private readonly ICompanyService CompanyService;

        public EmployeeController(ILoggerManager logger, ICompanyService companyService)
        {
            _logger = logger;
            CompanyService = companyService;
        }

        [HttpPost]
        [ProducesResponseType(typeof(EmployeeModel), 201)]
        [ProducesResponseType(typeof(ErrorResource), 400)]
        public async Task<IActionResult> PostAsync([FromBody] EmployeeModel employeeModel)
        {
            // var email = User.Identity.GetCurrentUserEmail();
            var result = await CompanyService.EmployeeService.SaveAsync(employeeModel);

            if (!result.Success)
            {
                return BadRequest(new ErrorResource(result.Message));
            }
            return Ok(result.Resource);
        }
    }
}