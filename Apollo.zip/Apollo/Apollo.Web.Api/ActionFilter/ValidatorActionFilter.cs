﻿using Apollo.Web.Api.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Net;

namespace Apollo.Web.Api.ActionFilter
{
    /// <summary>
    /// This class is needed to make the FluentValidation work in .Net core
    /// This action filter responsible in responding 400 status if there's a validation error
    /// </summary>
    public class ValidatorActionFilter : IActionFilter
    {
        public void OnActionExecuting(ActionExecutingContext actionContext)
        {
            if (!actionContext.ModelState.IsValid)
            {
                actionContext.Result = new ObjectResult(new ApiResourceValidationErrorWrapper(actionContext.ModelState)) { StatusCode = (int)HttpStatusCode.BadRequest };
            }
        }

        public void OnActionExecuted(ActionExecutedContext context)
        {

        }
    }
}
