namespace Apollo.Web.Api.Resources
{
    public class ProductsQueryResource : QueryResource
    {
        public int? CategoryId { get; set; }
    }
}