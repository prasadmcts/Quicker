using Apollo.Common.Constants;
using Apollo.Common.Extensions;
using System.Collections.Generic;

namespace Apollo.Web.Api.Resources
{
    public class ErrorResource
    {
        public bool Success => false;
        public List<string> Messages { get; private set; }

        public string Message { get { return Messages.Join(CommonConstants.CommaSeparator);  } }

        public ErrorResource(List<string> messages)
        {
            this.Messages = messages ?? new List<string>();
        }

        public ErrorResource(string message)
        {
            this.Messages = new List<string>();

            if(!message.IsNullOrWhiteSpace())
            {
                this.Messages.Add(message);
            }
        }
    }
}