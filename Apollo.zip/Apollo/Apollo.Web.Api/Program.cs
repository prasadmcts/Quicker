using Apollo.Data.Master.DbContexts;
using Apollo.Services.Interfaces.Security.Hashing;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.IO;

namespace Apollo.Web.Api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var host = BuildWebHost(args);

            //using (var scope = host.Services.CreateScope())
            //{
            //    var services = scope.ServiceProvider;
            //    var context = services.GetService<MasterContext>();
            //    var passwordHasher = services.GetService<IPasswordHasher>();
            //    MasterDatabaseSeed.Seed(context, passwordHasher);
            //}

            host.Run();
        }

        public static IWebHost BuildWebHost(string[] args)
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
                            .SetBasePath(Directory.GetCurrentDirectory())
                            .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                            .Build();

            /*
             * The call to ".UseIISIntegration" is necessary to fix issue while running the API from ISS. See the following links for reference:
             * - https://github.com/aspnet/IISIntegration/issues/242
             * - https://stackoverflow.com/questions/50112665/newly-created-net-core-gives-http-400-using-windows-authentication
            */

            return WebHost.CreateDefaultBuilder(args)
                    .UseIISIntegration()
                    .UseConfiguration(configuration)
                    .UseStartup<Startup>()
                    .Build();
        }
    }
}