using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Apollo.Data.Models.Master.Auth
{
    public class User : EntityBase<Guid>
    {
        public string Email { get; set; }

        public string Password { get; set; }

        public ICollection<UserRole> UserRoles { get; set; } = new Collection<UserRole>();
    }
}