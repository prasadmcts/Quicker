﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Apollo.Data.Models.Master.Auth
{
    public class Role :  EntityBase<Guid>
    {
        public string Name { get; set; }

        public ICollection<UserRole> UsersRole { get; set; } = new Collection<UserRole>();
    }
}
