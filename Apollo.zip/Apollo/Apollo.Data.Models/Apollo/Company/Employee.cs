﻿using System;

namespace Apollo.Data.Models.Apollo.Company
{
    public class Employee : EntityBase<Guid>
    {
        public string Name { get; set; }
        public bool Active { get; set; }
        public int Pin { get; set; }

        public Guid EmployerId { get; set; }
        public Employer Employer { get; set; }
    }
}