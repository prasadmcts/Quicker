﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Apollo.Data.Models.Apollo.Company
{
    public class Employer : EntityBase<Guid>
    {
        public string Name { get; set; }
        public bool Active { get; set; }
        public int Pin { get; set; }

        public ICollection<Employee> Employees { get; set; } = new Collection<Employee>();
    }
}