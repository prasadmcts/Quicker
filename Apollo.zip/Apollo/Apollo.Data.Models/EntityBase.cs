﻿using Apollo.Common.Model;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Apollo.Data.Models
{
    [Serializable]
    public abstract class EntityBase<TId> : IAuditable
    {
        //[Key]
        [Column(Order = 0)]
        //[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public virtual TId Id { get; set; }

        [Column(Order = 100)]
        public string CreatedBy { get; set; }

        [Column(Order = 101)]
        public DateTime CreatedDate { get; set; }

        [Column(Order = 102)]
        public string ModifiedBy { get; set; }

        [Column(Order = 103)]
        public DateTime? ModifiedDate { get; set; }

        [Column(Order = 104)]
        public bool IsDeleted { get; set; }
    }
}
