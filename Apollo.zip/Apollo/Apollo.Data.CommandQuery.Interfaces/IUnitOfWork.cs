using System.Threading.Tasks;

namespace Apollo.Data.CommandQuery.Interfaces
{
    public interface IUnitOfWork
    {
        Task ApolloCompleteAsync();
        Task MasterCompleteAsync();
    }
}