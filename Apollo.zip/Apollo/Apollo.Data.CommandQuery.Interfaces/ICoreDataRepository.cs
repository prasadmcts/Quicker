﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Apollo.Data.CommandQuery.Interfaces
{
    public interface ICoreDataRepository<T> : IDisposable where T : class, new()
    {
        Task AddAllAsync(IEnumerable<T> tList);
        Task<T> AddAsync(T t);
        Task<bool> AnyAsync(Expression<Func<T, bool>> match);
        void Attach(T entity);
        Task<int> CountAsync();
        void Delete(Expression<Func<T, bool>> match);
        void Delete(Guid id);
        void Delete(T t);
        void Dispose();
        Task<IList<T>> FindAllAsync(Expression<Func<T, bool>> match);
        Task<T> FindAsync(Expression<Func<T, bool>> match);
        Task<T> FirstOrDefaultAsync(Expression<Func<T, bool>> match);
        Task<IList<T>> GetAllAsync();
        Task<IList<T>> GetAllAsync(int pageIndex, int pageSize);
        Task<T> GetAsync(Guid id);
        object GetPropertyValue(object obj, string propertyName);
        T Update(T updated);
        Task<T> UpdateAsync(T updated, Guid key);
    }
}