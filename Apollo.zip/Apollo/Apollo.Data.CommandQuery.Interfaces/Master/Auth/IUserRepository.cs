﻿using Apollo.Common.Enums;
using Apollo.Data.Models.Master.Auth;
using System.Threading.Tasks;

namespace Apollo.Data.CommandQuery.Interfaces.Master.Auth
{
    public interface IUserRepository : ICoreDataRepository<User>
    {
        Task AddAsync(User user, ERole[] userRoles);
        Task<User> FindByEmailAsync(string email);
    }
}
