﻿using Apollo.Data.Models.Master.Auth;

namespace Apollo.Data.CommandQuery.Interfaces.Master.Auth
{
    public interface IRoleRepository : ICoreDataRepository<Role>
    {
    }
}
