﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Apollo.Data.CommandQuery.Interfaces.Master.Auth
{
    public interface IAuthRepository
    {
        IRoleRepository RoleRepository { get; set; }

        IUserRepository UserRepository { get; set; }
    }
}
