﻿using Apollo.Data.Models.Apollo.Company;

namespace Apollo.Data.CommandQuery.Interfaces.Apollo.Company
{
    public interface IEmployeeRepository : ICoreDataRepository<Employee>
    {
    }
}
