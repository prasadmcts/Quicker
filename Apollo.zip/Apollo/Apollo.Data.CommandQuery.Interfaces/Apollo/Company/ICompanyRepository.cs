﻿namespace Apollo.Data.CommandQuery.Interfaces.Apollo.Company
{
    public interface ICompanyRepository
    {
        IEmployeeRepository EmployeeRepository { get; set; }

        IEmployerRepository EmployerRepository { get; set; }
    }
}