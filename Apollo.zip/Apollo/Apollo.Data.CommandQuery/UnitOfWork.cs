using Apollo.Data.Apollo.DbContexts;
using Apollo.Data.CommandQuery.Interfaces;
using Apollo.Data.Master.DbContexts;
using System.Threading.Tasks;

namespace Apollo.Data.CommandQuery
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ApolloContext _apolloContext;
        private readonly MasterContext _masterContext;

        public UnitOfWork(ApolloContext apolloContext, MasterContext masterContext)
        {
            _apolloContext = apolloContext;
            _masterContext = masterContext;
        }

        public async Task ApolloCompleteAsync()
        {
            await _apolloContext.SaveChangesAsync();
        }

        public async Task MasterCompleteAsync()
        {
            await _masterContext.SaveChangesAsync();
        }
    }
}