﻿using Apollo.Data.Apollo.DbContexts;

namespace Apollo.Data.CommandQuery
{
    public abstract class ApolloCoreDataRepositoryBase<T> : CoreDataRepository<T> where T : class, new()
    {
        protected readonly ApolloContext _apolloContext;

        public ApolloCoreDataRepositoryBase(ApolloContext apolloContext) : base(apolloContext)
        {
            _apolloContext = apolloContext;
        }
    }
}
