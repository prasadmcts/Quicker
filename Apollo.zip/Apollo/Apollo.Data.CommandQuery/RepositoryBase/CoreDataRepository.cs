﻿using Apollo.Data.CommandQuery.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Apollo.Common.Extensions;

namespace Apollo.Data.CommandQuery
{
    public abstract class CoreDataRepository<T> : ICoreDataRepository<T> where T : class, new()
    {
        private readonly DbContext Context;

        protected CoreDataRepository(DbContext context)
        {
            Context = context;
        }

        public async Task<T> GetAsync(Guid id)
        {
            return await Context.Set<T>().FindAsync(id);
        }

        public async Task<IList<T>> GetAllAsync()
        {
            return await Context.Set<T>().AsNoTracking().ToListAsync();
        }

        public async Task<IList<T>> GetAllAsync(int pageIndex, int pageSize)
        {
            return await Context.Set<T>().AsNoTracking().Skip(pageIndex).Take(pageSize).ToListAsync();
        }

        public async Task<T> FindAsync(Expression<Func<T, bool>> match)
        {
            return await Context.Set<T>().SingleOrDefaultAsync(match);
        }

        public async Task<IList<T>> FindAllAsync(Expression<Func<T, bool>> match)
        {
            return await Context.Set<T>().Where(match).ToListAsync();
        }

        public async Task<T> AddAsync(T t)
        {
            t.NotNull();
            //T entityToAdd = ProcessIdFields(t, Actions.Add);
            await Context.Set<T>().AddAsync(t);
            return t;
        }

        public async Task AddAllAsync(IEnumerable<T> tList)
        {
            //tList.ToList().ForEach(t => t = ProcessIdFields(t, Actions.Add));
            await Context.Set<T>().AddRangeAsync(tList);
        }

        public T Update(T updated)
        {
            updated.NotNull();
            Attach(updated);
            Context.Entry(updated).State = EntityState.Modified;
            return updated;
        }

        public async Task<T> UpdateAsync(T updated, Guid key)
        {
            updated.NotNull();
            var existing = await Context.Set<T>().FindAsync(key);
            if (existing != null)
            {
                Context.Entry(existing).CurrentValues.SetValues(updated);
            }
            return existing;
        }

        public void Delete(T t)
        {
            Context.Set<T>().Remove(t);
        }

        public async void Delete(Guid id)
        {
            var t = await GetAsync(id);
            Context.Set<T>().Remove(t);
        }

        public async void Delete(Expression<Func<T, bool>> match)
        {
            var records = await FindAllAsync(match);
            foreach (var record in records)
            {
                Delete(record);
            }
        }

        public async Task<T> FirstOrDefaultAsync(Expression<Func<T, bool>> match)
        {
            return await Context.Set<T>().FirstOrDefaultAsync(match);
        }

        public async Task<int> CountAsync()
        {
            return await Context.Set<T>().CountAsync();
        }

        public async Task<bool> AnyAsync(Expression<Func<T, bool>> match)
        {
            return await Context.Set<T>().AnyAsync(match);
        }

        public void Attach(T entity)
        {
            Context.Set<T>().Attach(entity);
        }

        public object GetPropertyValue(object obj, string propertyName)
        {
            var objType = obj.GetType();
            var prop = objType.GetProperty(propertyName);

            return prop.GetValue(obj, null);
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    Context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}