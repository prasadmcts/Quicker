﻿using Apollo.Data.Master.DbContexts;

namespace Apollo.Data.CommandQuery
{
    public abstract class MasterCoreDataRepositoryBase<T> : CoreDataRepository<T> where T : class, new()
    {
        protected readonly MasterContext _masterContext;
        public MasterCoreDataRepositoryBase(MasterContext masterContext) : base(masterContext)
        {
            _masterContext = masterContext;
        }
    }
}
