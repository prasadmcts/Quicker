﻿using Apollo.Data.Apollo.DbContexts;
using Apollo.Data.CommandQuery.Interfaces.Apollo.Company;
using Apollo.Data.Models.Apollo.Company;

namespace Apollo.Data.CommandQuery.Apollo.Company
{
    public class EmployeeRepository : ApolloCoreDataRepositoryBase<Employee>, IEmployeeRepository
    {
        public EmployeeRepository(ApolloContext apolloContext) : base(apolloContext)
        {
        }
    }
}
