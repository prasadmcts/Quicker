﻿using Apollo.Data.Apollo.DbContexts;
using Apollo.Data.CommandQuery.Interfaces.Apollo.Company;
using Apollo.Data.Models.Apollo.Company;

namespace Apollo.Data.CommandQuery.Apollo.Company
{
    public class EmployerRepository : ApolloCoreDataRepositoryBase<Employer>, IEmployerRepository
    {
        public EmployerRepository(ApolloContext apolloContext) : base(apolloContext)
        {
        }
    }
}
