﻿using Apollo.Data.CommandQuery.Interfaces.Apollo.Company;

namespace Apollo.Data.CommandQuery.Apollo.Company
{
    public class CompanyRepository : ICompanyRepository
    {
        public CompanyRepository(IEmployeeRepository employeeRepository, IEmployerRepository employerRepository)
        {
            EmployeeRepository = employeeRepository;
            EmployerRepository = employerRepository;
        }
        public IEmployeeRepository EmployeeRepository { get; set; }
        public IEmployerRepository EmployerRepository { get; set; }
    }
}
