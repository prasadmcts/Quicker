﻿using Apollo.Data.CommandQuery.Interfaces.Master.Auth;
using Apollo.Data.Master.DbContexts;
using Apollo.Data.Models.Master.Auth;

namespace Apollo.Data.CommandQuery.Company
{
    public class RoleRepository : MasterCoreDataRepositoryBase<Role>, IRoleRepository
    {
        public RoleRepository(MasterContext masterContext) : base(masterContext)
        {
        }
    }
}
