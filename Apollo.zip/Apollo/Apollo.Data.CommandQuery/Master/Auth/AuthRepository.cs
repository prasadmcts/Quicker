﻿using Apollo.Data.CommandQuery.Interfaces.Master.Auth;

namespace Apollo.Data.CommandQuery.Master.Auth
{
    public class AuthRepository : IAuthRepository
    {
        public AuthRepository(IUserRepository userRepository, IRoleRepository roleRepository)
        {
            UserRepository = userRepository;
            RoleRepository = roleRepository;
        }
        public IUserRepository UserRepository { get; set; }
        public IRoleRepository RoleRepository { get; set; }
    }
}
