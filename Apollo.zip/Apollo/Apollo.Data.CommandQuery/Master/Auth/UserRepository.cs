﻿using Apollo.Common.Enums;
using Apollo.Data.CommandQuery.Interfaces.Master.Auth;
using Apollo.Data.Master.DbContexts;
using Apollo.Data.Models.Master.Auth;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace Apollo.Data.CommandQuery.Company
{
    public class UserRepository : MasterCoreDataRepositoryBase<User>, IUserRepository
    {
        public UserRepository(MasterContext masterContext) : base(masterContext)
        {
        }

        public async Task AddAsync(User user, ERole[] userRoles)
        {
            var _roles = userRoles.Select(r => r.ToString()).ToList();
            var roles = await _masterContext.Roles.Where(r => _roles.Contains(r.Name)).ToListAsync();

            foreach (var role in roles)
            {
                user.UserRoles.Add(new UserRole { RoleId = role.Id });
            }

            _masterContext.Users.Add(user);
        }

        public async Task<User> FindByEmailAsync(string email)
        {
            return await _masterContext.Users.Include(u => u.UserRoles)
                                       .ThenInclude(ur => ur.Role)
                                       .SingleOrDefaultAsync(u => u.Email == email);
        }
    }
}
