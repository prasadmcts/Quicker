﻿using Apollo.Data.Models.Apollo.Company;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Apollo.Data.Apollo.DbContexts
{
    public class ApolloDatabaseSeed
    {
        public static void Seed(ApolloContext context)
        {
            context.Database.EnsureCreated();

            if (context.Employee.Count() == 0)
            {
                var employer = new List<Employer>
                {
                    new Employer
                    {
                        Name = "ANZ",
                        Active = true,
                        Pin = 5678,

                        IsDeleted = false,
                        CreatedBy = "Prasad",
                        CreatedDate = DateTime.UtcNow,
                        ModifiedBy = "Prasad",
                        ModifiedDate = DateTime.UtcNow,

                        Employees = new List<Employee>
                        {
                            new Employee
                            {
                                Name = "Prasad Kanaparthi",
                                Active = true,
                                Pin = 1234,

                                IsDeleted = false,
                                CreatedBy = "Prasad",
                                CreatedDate = DateTime.UtcNow,
                                ModifiedBy = "Prasad",
                                ModifiedDate = DateTime.UtcNow,
                            }
                        }
                    }
                };

                context.Employer.AddRange(employer);
                context.SaveChanges();
            }
        }
    }
}