﻿using Apollo.Data.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;

namespace Apollo.Data.Apollo.Configurations
{
    public class EntityTypeConfigurationApollo<TEntity> : IEntityTypeConfiguration<TEntity> where TEntity : EntityBase<Guid>
    {
        public virtual void Configure(EntityTypeBuilder<TEntity> builder)
        {
            builder.HasKey(x => x.Id);

            builder.Property(x => x.Id).HasColumnName("Id").ValueGeneratedOnAdd();
        }
    }
}
