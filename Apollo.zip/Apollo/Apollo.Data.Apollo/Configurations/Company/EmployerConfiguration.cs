﻿using Apollo.Common.Constants;
using Apollo.Data.Models.Apollo.Company;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;

namespace Apollo.Data.Apollo.Configurations.Company
{
    [Serializable]
    public class EmployerConfiguration : EntityTypeConfigurationApollo<Employer>
    {
        public override void Configure(EntityTypeBuilder<Employer> builder)
        {
            builder.ToTable(DatabaseTableConstants.Employer, DatabaseSchemaConstants.dbo);
            builder.Property(c => c.Name).HasMaxLength(DatabaseTableConstants.Length100).IsRequired();
            base.Configure(builder);
        }
    }
}
