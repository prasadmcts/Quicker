﻿using Apollo.Common.Constants;
using Apollo.Data.Models.Apollo.Company;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;

namespace Apollo.Data.Apollo.Configurations.Company
{
    [Serializable]
    public class EmployeeConfiguration : EntityTypeConfigurationApollo<Employee>
    {
        public override void Configure(EntityTypeBuilder<Employee> builder)
        {
            builder.ToTable(DatabaseTableConstants.Employee, DatabaseSchemaConstants.dbo);
            builder.Property(c => c.Name).HasMaxLength(DatabaseTableConstants.Length100).IsRequired();
            base.Configure(builder);
        }
    }
}