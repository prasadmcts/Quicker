﻿using Apollo.Common.Constants;
using Apollo.Data.Models.Master.Auth;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;

namespace Apollo.Data.Master.Configurations.Auth
{
    [Serializable]
    public class UserConfiguration : EntityTypeConfigurationMaster<User>
    {
        public override void Configure(EntityTypeBuilder<User> builder)
        {
            builder.ToTable(DatabaseTableConstants.User, DatabaseSchemaConstants.dbo);
            builder.Property(c => c.Email).HasMaxLength(DatabaseTableConstants.Length255).IsRequired();
            builder.Property(c => c.Password).IsRequired();
            base.Configure(builder);
        }
    }
}
