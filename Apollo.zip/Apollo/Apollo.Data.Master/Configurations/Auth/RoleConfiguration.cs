﻿using Apollo.Common.Constants;
using Apollo.Data.Models.Master.Auth;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;

namespace Apollo.Data.Master.Configurations.Auth
{
    [Serializable]
    public class RoleConfiguration : EntityTypeConfigurationMaster<Role>
    {
        public override void Configure(EntityTypeBuilder<Role> builder)
        {
            builder.ToTable(DatabaseTableConstants.Role, DatabaseSchemaConstants.dbo);
            builder.Property(c => c.Name).HasMaxLength(DatabaseTableConstants.Length50).IsRequired();
            base.Configure(builder);
        }
    }
}
