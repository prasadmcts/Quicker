﻿using Apollo.Data.Models;
using Apollo.Data.Models.Master.Auth;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace Apollo.Data.Master.DbContexts
{
    public class MasterContext : DbContext
    {
        public MasterContext()
        { }

        public MasterContext(DbContextOptions<MasterContext> options) : base(options)
        { }

        public DbSet<User> Users { get; set; }
        public DbSet<Role> Roles { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                // optionsBuilder.UseSqlServer(@"Server=INLT-9497733C\SQLEXPRESS01;Database=Master;Trusted_Connection=True;ConnectRetryCount=0");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            Assembly assemblyWithConfigurations = GetType().Assembly; //get whatever assembly you want
            modelBuilder.ApplyConfigurationsFromAssembly(assemblyWithConfigurations);

            base.OnModelCreating(modelBuilder);
        }

        public async Task<int> SaveChangesAsync(bool acceptAllChangesOnSuccess = true)
        {
            var entities = ChangeTracker.Entries().Where(x => x.Entity is EntityBase<Guid> && (x.State == EntityState.Added || x.State == EntityState.Modified || x.State == EntityState.Deleted));
            //var currentUsername = HttpContext.Current != null && HttpContext.Current.User != null ? HttpContext.Current.User.Identity.Name : "Anonymous";
            var currentUsername = "Prasad";

            foreach (var entity in entities)
            {
                if (entity.State == EntityState.Added)
                {
                    ((EntityBase<Guid>)entity.Entity).CreatedDate = DateTime.UtcNow;
                    ((EntityBase<Guid>)entity.Entity).CreatedBy = currentUsername;
                }
                else if (entity.State == EntityState.Modified || entity.State == EntityState.Deleted)
                {
                    ((EntityBase<Guid>)entity.Entity).ModifiedDate = DateTime.UtcNow;
                    ((EntityBase<Guid>)entity.Entity).ModifiedBy = currentUsername;
                }
            }
            return await base.SaveChangesAsync(acceptAllChangesOnSuccess, default);
        }
    }
}
