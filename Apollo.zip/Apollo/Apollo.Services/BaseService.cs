﻿using Apollo.Common.Extensions;
using Apollo.Data.CommandQuery.Interfaces;
using Apollo.Data.CommandQuery.Interfaces.Apollo.Company;
using Apollo.Services.Models;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;

namespace Apollo.Services
{
    //public abstract class BaseService<TDataModel, TEntity> : IBaseService<TDataModel, TEntity> where TDataModel : class where TEntity : class
    //{
    //    # region ctor

    //    /// <summary>
    //    /// TODO: Why 2 constrcutor's ? Inject CoreDataRepository 
    //    /// </summary>
    //    /// <param name="logger"></param>
    //    /// <param name="modelFactory"></param>
    //    /// <param name="companyRepository"></param>
    //    protected BaseService(ILog logger, ModelFactory<TDataModel, TEntity> modelFactory, ICompanyRepository companyRepository)
    //    {
    //        logger.NotNull();
    //        modelFactory.NotNull();
    //        companyRepository.NotNull();

    //        Logger = logger;
    //        ModelFactory = modelFactory;
    //        CompanyRepository = companyRepository;
    //    }

    //    protected BaseService(ILog logger, ModelFactory<TDataModel, TEntity> modelFactory, ICoreDataRepository<TEntity> coreDataRepository, ICompanyRepository companyRepository)
    //    {
    //        logger.NotNull();
    //        modelFactory.NotNull();
    //        coreDataRepository.NotNull();
    //        companyRepository.NotNull();

    //        Logger = logger;
    //        ModelFactory = modelFactory;
    //        CoreDataRepository = coreDataRepository;
    //        CompanyRepository = companyRepository;
    //    }

    //    #endregion

    //    #region DI

    //    protected ILog Logger { get; set; }

    //    protected IMapper Mapper { get; set; }

    //    protected ModelFactory<TDataModel, TEntity> ModelFactory { get; set; }

    //    private ICoreDataRepository<TEntity> CoreDataRepository { get; set; }

    //    protected ICompanyRepository CompanyRepository { get; set; }

    //    #endregion

    //    #region Default Methods

    //    public async Task Create(TDataModel model)
    //    {
    //        var entity = ModelFactory.Create(model);
    //        await CoreDataRepository.AddAsync(entity);
    //    }

    //    public async Task Delete(Guid id)
    //    {
    //        await Task.Yield();
    //        CoreDataRepository.Delete(id);
    //    }

    //    public async Task<IList<TDataModel>> GetAll()
    //    {
    //        var lstEntities = await CoreDataRepository.GetAllAsync();
    //        return ModelFactory.Create(lstEntities);
    //    }

    //    public async Task<TDataModel> GetById(Guid id)
    //    {
    //        var entity = await CoreDataRepository.GetAsync(id);
    //        return ModelFactory.Create(entity);
    //    }

    //    public async Task Save(TDataModel model)
    //    {
    //        await Task.Yield();
    //        var id = (model as BaseModel<Guid>)?.Id;
    //        if (id.IsNullOrEmpty())
    //        {
    //            await Create(model);
    //        }
    //        else
    //        {
    //            await Update(id.Value, model);
    //        }
    //    }

    //    public async Task Update(Guid id, TDataModel model)
    //    {
    //        await Task.Yield();
    //        var entity = ModelFactory.Create(model);
    //        CoreDataRepository.Update(entity, id);
    //    }

    //    #endregion

    //    public void Dispose()
    //    {
    //        throw new System.NotImplementedException();
    //    }
    //}

    public abstract class BaseService
    {
        protected BaseService(ILogger<BaseService> logger, IUnitOfWork unitOfWork, IMemoryCache cache, ModelFactory modelFactory, ICompanyRepository companyRepository)
        {
            logger.NotNull();
            unitOfWork.NotNull();
            cache.NotNull();
            modelFactory.NotNull();
            companyRepository.NotNull();

            Logger = logger;
            UnitOfWork = unitOfWork;
            Cache = cache;
            ModelFactory = modelFactory;
            CompanyRepository = companyRepository;
        }

        protected ILogger<BaseService> Logger { get; set; }
        protected ICompanyRepository CompanyRepository { get; set; }
        public IUnitOfWork UnitOfWork { get; set; }
        public IMemoryCache Cache { get; set; }
        public ModelFactory ModelFactory { get; set; }
        
    }
}