﻿using Apollo.Services.Interfaces.Apollo.Company;

namespace Apollo.Services.Apollo.Company
{
    public class CompanyService : ICompanyService
    {
        public CompanyService(IEmployeeService employeeService, IEmployerService employerService)
        {
            EmployeeService = employeeService;
            EmployerService = employerService;
        }
        public IEmployeeService EmployeeService { get; set; }
        public IEmployerService EmployerService { get; set; }
    }
}
