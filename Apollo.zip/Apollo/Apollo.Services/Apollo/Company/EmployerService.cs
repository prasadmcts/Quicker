﻿using Apollo.Data.CommandQuery.Interfaces;
using Apollo.Data.CommandQuery.Interfaces.Apollo.Company;
using Apollo.Services.Interfaces.Apollo.Company;
using Apollo.Services.Models;
using Apollo.Services.Models.Apollo.Company;
using Apollo.Services.Models.Communication;
using Apollo.Services.Models.Queries;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Apollo.Services.Apollo.Company
{
    public class EmployerService : BaseService, IEmployerService
    {
        public EmployerService(ILogger<EmployerService> logger, IUnitOfWork unitOfWork, IMemoryCache cache, ModelFactory modelFactory, ICompanyRepository companyRepository) : base(logger, unitOfWork, cache, modelFactory, companyRepository)
        {
        }
        public Task<EmployerResponse> DeleteAsync(Guid id)
        {
            throw new System.NotImplementedException();
        }

        public Task<IEnumerable<EmployerModel>> ListAsync()
        {
            throw new System.NotImplementedException();
        }

        public Task<QueryResult<EmployerModel>> ListAsync(EmployerQuery query)
        {
            throw new System.NotImplementedException();
        }

        public Task<EmployerResponse> SaveAsync(EmployerModel Employer)
        {
            throw new System.NotImplementedException();
        }

        public Task<EmployerResponse> UpdateAsync(Guid id, EmployerModel Employer)
        {
            throw new System.NotImplementedException();
        }
    }
}
