﻿using Apollo.Data.CommandQuery.Interfaces;
using Apollo.Data.CommandQuery.Interfaces.Apollo.Company;
using Apollo.Services.Interfaces.Apollo.Company;
using Apollo.Services.Models;
using Apollo.Services.Models.Apollo.Company;
using Apollo.Services.Models.Communication;
using Apollo.Services.Models.Queries;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Apollo.Services.Apollo.Company
{
    //public class EmployeeService<TDataModel, TEntity> : BaseService<TDataModel, TEntity>, IEmployeeService<TDataModel, TEntity> where TEntity : class where TDataModel : class
    //{
    //    public EmployeeService(ILog logger, ModelFactory<TDataModel, TEntity> modelFactory, ICompanyRepository companyRepository)
    //        : base(logger, modelFactory, companyRepository)
    //    {
    //    }
    //}

    public class EmployeeService : BaseService, IEmployeeService
    {
        public EmployeeService(ILogger<EmployeeService> logger, IUnitOfWork unitOfWork, IMemoryCache cache, ModelFactory modelFactory, ICompanyRepository companyRepository) : base(logger, unitOfWork, cache, modelFactory, companyRepository)
        {
        }
        public Task<EmployeeResponse> DeleteAsync(Guid id)
        {
            throw new System.NotImplementedException();
        }

        public Task<IEnumerable<EmployeeModel>> ListAsync()
        {
            throw new System.NotImplementedException();
        }

        public Task<QueryResult<EmployeeModel>> ListAsync(EmployeeQuery query)
        {
            throw new System.NotImplementedException();
        }

        public async Task<CommonResponse<EmployeeModel>> SaveAsync(EmployeeModel employeeModel)
        {
            try
            {
                var employee = ModelFactory.Create(employeeModel);

                await CompanyRepository.EmployeeRepository.AddAsync(employee);

                await UnitOfWork.ApolloCompleteAsync();

                return new CommonResponse<EmployeeModel>(ModelFactory.Create(employee));
            }
            catch (Exception ex)
            {
                // Do some logging stuff
                Logger.LogError($"{ex.Message} {ex.StackTrace}", "SaveAsync");
                return new CommonResponse<EmployeeModel>($"An error occurred when saving the category: {ex.Message}");
            }
        }

        public Task<EmployeeResponse> UpdateAsync(Guid id, EmployeeModel employee)
        {
            throw new System.NotImplementedException();
        }
    }
}