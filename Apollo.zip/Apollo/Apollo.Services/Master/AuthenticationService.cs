﻿using Apollo.Services.Interfaces.Master;
using Apollo.Services.Interfaces.Security.Hashing;
using Apollo.Services.Interfaces.Security.Tokens;
using Apollo.Services.Models.Communication;
using System.Threading.Tasks;

namespace Apollo.Services.Master
{
    public class AuthenticationService : IAuthenticationService
    {
        private readonly IUserService _userService;
        private readonly IPasswordHasher _passwordHasher;
        private readonly ITokenHandler _tokenHandler;

        public AuthenticationService(IUserService userService, IPasswordHasher passwordHasher, ITokenHandler tokenHandler)
        {
            _tokenHandler = tokenHandler;
            _passwordHasher = passwordHasher;
            _userService = userService;
        }

        public async Task<TokenResponse> CreateAccessTokenAsync(string email, string password)
        {
            var user = await _userService.FindByEmailAsync(email);

            if (user == null || !_passwordHasher.PasswordMatches(password, user.Password))
            {
                return new TokenResponse("Invalid credentials.");
            }

            var token = _tokenHandler.CreateAccessToken(user);

            return new TokenResponse(token);
        }

        public async Task<TokenResponse> RefreshTokenAsync(string refreshToken, string userEmail)
        {
            var token = _tokenHandler.TakeRefreshToken(refreshToken);

            if (token == null)
            {
                return new TokenResponse("Invalid refresh token.");
            }

            if (token.IsExpired())
            {
                return new TokenResponse("Expired refresh token.");
            }

            var user = await _userService.FindByEmailAsync(userEmail);
            if (user == null)
            {
                return new TokenResponse("Invalid refresh token.");
            }

            var accessToken = _tokenHandler.CreateAccessToken(user);
            return new TokenResponse(accessToken);
        }

        public void RevokeRefreshToken(string refreshToken)
        {
            _tokenHandler.RevokeRefreshToken(refreshToken);
        }
    }
}
