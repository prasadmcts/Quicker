﻿using System.Text.RegularExpressions;

namespace Apollo.Common.Extensions
{
    public static class RegexExtensions
    {
        public static string ConvertWhitespacesToSingleSpaces(this string value) => value.Replace(@"\s+", " ");

        //ditches html tags - note it doesnt get rid of things like &nbsp;
        public static string StripHtml(this string html)
        {
            if (html.IsNullOrWhiteSpace())
                return string.Empty;

            return html.Replace(@"<[^>]*>", string.Empty);
        }

        public static bool Match(this string value, string pattern) =>  Regex.IsMatch(value, pattern);

        public static string Replace(this string input, string pattern, string replacement) => Regex.Replace(input, pattern, replacement);
    }
}
