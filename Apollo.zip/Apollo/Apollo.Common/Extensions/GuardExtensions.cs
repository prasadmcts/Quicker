﻿using GuardNet;

namespace Apollo.Common.Extensions
{
    public static class GuardExtensions
    {
        public static void NotNull<TParam>(this TParam param, string paramName) where TParam : class
        {
            Guard.NotNull<TParam>(param, paramName);
        }

        public static void NotNull<TParam>(this TParam param) where TParam : class
        {
            NotNull<TParam>(param, nameof(param));
        }
    }
}
