﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Apollo.Common.Extensions
{
    public static class TimeSpanExtensions
    {
    }
}
