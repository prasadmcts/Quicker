﻿using System;
using System.Globalization;

namespace Apollo.Common.Extensions
{
    public static class DateTimeExtensions
    {
        /// <summary>
        /// This will convert the date with the right time zone
        /// System.Convert.ToDateTime does not work in openshift!
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public static DateTime ConvertToDateTime(string date)
        {
            if (string.IsNullOrEmpty(date))
                return new DateTime();

            string[] format = { "yyyy-dd-MM", "dd-MM-yyyy", "dd/MM/yyyy", "d/MM/yyyy", "yyyy/MM/dd" };

            if (!DateTime.TryParseExact(date, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out var validDateTime))
                throw new Exception("Invalid Date");
            return validDateTime;
        }


        public static string OrdinalSuffix(this DateTime datetime)
        {
            int day = datetime.Day;
            if (day % 100 >= 11 && day % 100 <= 13)
                return string.Concat(day, "th");
            switch (day % 10)
            {
                case 1:
                    return string.Concat(day, "st");
                case 2:
                    return string.Concat(day, "nd");
                case 3:
                    return string.Concat(day, "rd");
                default:
                    return string.Concat(day, "th");
            }
        }
    }
}
