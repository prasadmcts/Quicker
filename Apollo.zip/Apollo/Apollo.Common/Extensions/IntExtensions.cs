﻿namespace Apollo.Common.Extensions
{
    public static class IntExtensions
    {
        public static bool IsBetween(this int number, int a, int b) =>  a <= number && number <= b;

        public static int TryParse(this string input, int defaultValue = default) => int.TryParse(input, out int intOutParameter) ? intOutParameter : defaultValue;

        public static long TryParse(this string input, long defaultValue = default) => long.TryParse(input, out long intOutParameter) ? intOutParameter : defaultValue;
    }
}
