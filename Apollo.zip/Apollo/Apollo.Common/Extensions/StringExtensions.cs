﻿using Apollo.Common.Constants;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Apollo.Common.Extensions
{
    public static class StringExtensions
    {
        public static string TrimAndReduce(this string str) =>  str.ConvertWhitespacesToSingleSpaces().Trim();

        public static string Join<TItem>(this IEnumerable<TItem> enumerable, string separator = "") => string.Join(separator, enumerable.Select(e => e.ToString()));

        public static string RemoveWhitespace(this string theString) => theString.Split(default(string[]), StringSplitOptions.RemoveEmptyEntries).Join();

        public static bool IsNullOrWhiteSpace(this string theString) => string.IsNullOrWhiteSpace(theString);

        public static string ToNullableValue(this string theString, string nullValue) => theString.IsNullOrWhiteSpace() ? nullValue : theString;

        /// Like linq take - takes the first x characters
        public static string Take(this string theString, int count, bool ellipsis = false)
        {
            int lengthToTake = Math.Min(count, theString.Length);
            var cutDownString = theString.Substring(0, lengthToTake);

            if (ellipsis && lengthToTake < theString.Length)
                cutDownString += CommonConstants.CutDownString;

            return cutDownString;
        }

        //like linq skip - skips the first x characters and returns the remaining string
        public static string Skip(this string theString, int count)
        {
            int startIndex = Math.Min(count, theString.Length);
            var cutDownString = theString.Substring(startIndex - 1);

            return cutDownString;
        }

        public static string Reverse(this string theString)
        {
            char[] chars = theString.ToCharArray();
            Array.Reverse(chars);
            return new string(chars);
        }

        //"a string {0}".Format("blah") vs string.Format("a string {0}", "blah")
        public static string With(this string format, params object[] args)
        {
            return string.Format(format, args);
        }
    }
}
