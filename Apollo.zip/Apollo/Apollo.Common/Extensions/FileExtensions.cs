﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace Apollo.Common.Extensions
{
    public static class FileExtensions
    {
        public static string GetExecutingAssemblyRootFolder() => Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);

        public static void MoveFileWithOverwrite(this string filename, string sourcePath, string destinationPath)
        {
            var fileToCopy = Path.Combine(sourcePath, filename);
            if (File.Exists(fileToCopy))
            {
                var destinationFile = Path.Combine(destinationPath, filename);
                if (File.Exists(destinationFile)) File.SetAttributes(destinationFile, FileAttributes.Normal);
                File.Copy(fileToCopy, destinationFile, true);
                File.SetAttributes(fileToCopy, FileAttributes.Normal);
                File.Delete(fileToCopy);
            }
        }

        public static void MoveFileWithOverwrite(this string fullSourcePath, string fullDestinationPath)
        {
            if (File.Exists(fullSourcePath))
            {
                if (File.Exists(fullDestinationPath)) File.SetAttributes(fullDestinationPath, FileAttributes.Normal);
                File.Copy(fullSourcePath, fullDestinationPath, true);
                File.SetAttributes(fullSourcePath, FileAttributes.Normal);
                File.Delete(fullSourcePath);
            }
        }

        public static void CopyFile(this string srcFullPath, string dstfullPath, bool overwrite)
        {
            if (!File.Exists(srcFullPath)) return;

            if (overwrite && File.Exists(dstfullPath))
            {
                File.SetAttributes(dstfullPath, FileAttributes.Normal);
            }

            File.Copy(srcFullPath, dstfullPath, overwrite);
        }

        public static void CopyAllFiles(this string srcDir, string dstDir, bool overwrite, string quicModuleVersion)
        {
            if (Directory.Exists(srcDir) && Directory.Exists(dstDir))
            {
                var files = Directory.GetFiles(srcDir, "*.*", SearchOption.AllDirectories);

                foreach (var file in files)
                {
                    var dstFilename = Path.Combine(dstDir, Path.GetFileName(file));
                    CopyFile(file, dstFilename, true, quicModuleVersion);
                }
            }
        }

        public static void CopyAllFiles(this string srcDir, string dstDir, bool overwrite)
        {
            if (Directory.Exists(srcDir) && Directory.Exists(dstDir))
            {
                var files = Directory.GetFiles(srcDir, "*.*", SearchOption.AllDirectories);

                foreach (var file in files)
                {
                    var dstFilename = Path.Combine(dstDir, Path.GetFileName(file));
                    CopyFile(file, dstFilename, overwrite);
                }
            }
        }

        public static void CopyFile(this  string srcFullPath, string dstfullPath, bool overwrite, string quicModuleVersion)
        {
            if (!File.Exists(srcFullPath)) return;

            if (overwrite && File.Exists(dstfullPath))
            {
                File.SetAttributes(dstfullPath, FileAttributes.Normal);
            }

            if (File.Exists(dstfullPath) && overwrite)
            {
                File.SetAttributes(dstfullPath, FileAttributes.Normal);
            }

            if (Path.GetExtension(srcFullPath).ToLower() == ".csv")
            {
                string tokenFileText = File.ReadAllText(srcFullPath);
                tokenFileText = tokenFileText.Replace(@"<MV>", quicModuleVersion);
                Console.WriteLine("Static file name {0} will be replaced with token {1}", srcFullPath, quicModuleVersion);
                File.WriteAllText(dstfullPath, tokenFileText);
            }
            else
                File.Copy(srcFullPath, dstfullPath, overwrite);
        }

        public static void DeleteDirectory(this string path)
        {
            var files = Directory.GetFiles(path);

            foreach (var file in files)
            {
                File.SetAttributes(file, FileAttributes.Normal);
                File.Delete(file);
            }
            if (Directory.Exists(path))
            {
                Directory.Delete(path);
            }
        }

        public static void CreateFolderIfNotExist(this string folderName)
        {
            if (!string.IsNullOrEmpty(folderName))
            {
                if (!Directory.Exists(folderName))
                {
                    Directory.CreateDirectory(folderName);
                }
            }
        }

        public static IEnumerable<string> ReadFile(this string path)
        {
            var inStream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);

            using StreamReader reader = new StreamReader(inStream);
            while (!reader.EndOfStream)
            {
                yield return reader.ReadLine();
            }
        }

        public static string ReadAllText(this string filePath) => File.ReadAllText(filePath);

        public static StreamWriter OpenWrite(this string filename)
        {
            try
            {
                return new StreamWriter(filename);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void DeleteFileIfExists(this string filePath)
        {
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
            }
        }

        public static void CreateFile(this string filePath) => File.Create(filePath);
    }
}
