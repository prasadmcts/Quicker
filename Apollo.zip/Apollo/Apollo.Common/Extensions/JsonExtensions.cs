﻿using Newtonsoft.Json;

namespace Apollo.Common.Extensions
{
    public static class JsonExtensions
    {
        public static string ToJson(this object jsonObj) => jsonObj.JsonSerialize();
        public static T FromJson<T>(this string json) => json.JsonDeserialize<T>();
        private static string JsonSerialize<T>(this T jsonObj) => JsonConvert.SerializeObject(jsonObj);
        private static T JsonDeserialize<T>(this string json) => JsonConvert.DeserializeObject<T>(json);
        public static T JsonDeserializePath<T>(this string filePath) => filePath.ReadAllText().JsonDeserialize<T>();
    }
}
