﻿namespace Apollo.Common.Extensions
{
    public static class CommonExtensions
    {
    }
}
