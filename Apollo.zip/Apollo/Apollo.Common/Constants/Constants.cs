﻿namespace Apollo.Common.Constants
{
    public static class Routes
    {
        public const string SignUp = nameof(SignUp);
    }

    public static class CommonConstants
    {
        public const string InternalServer = "Internal Server Error from the custom middleware.";
        public const string IsMandatory = "is mandatory.";
        public const string CommaSeparator = ",";
        public const string CutDownString = "...";

        public const int Length32 = 32;
        public const int Length50 = 50;
        public const int Length100 = 100;
        public const int Length255 = 255;
    }

    public static class ErrorConstants
    {
        public const string ValueCannotBeNull = "Value cannot be null";
    }

    #region Database

    public static class DatabaseTableConstants
    {
        #region ColumnLength
        public const int Length50 = CommonConstants.Length50;
        public const int Length100 = CommonConstants.Length100;
        public const int Length255 = CommonConstants.Length255;
        #endregion

        #region Apollo Tables
        public const string Employee = nameof(Employee);
        public const string Employer = nameof(Employer);
        #endregion

        #region Master Tables
        public const string Role = nameof(Role);
        public const string User = nameof(User);
        #endregion
    }

    public static class DatabaseSchemaConstants
    {
        public const string dbo = nameof(dbo);
    }

    #endregion

    public class ConfiguarionConstants
    {
        public const string AppConfiguration = nameof(AppConfiguration);
        public const string Key = nameof(Key);
        public const string LogsPath = nameof(LogsPath);

        public const string MailSettings = nameof(MailSettings);
        public const string SmtpHost = nameof(SmtpHost);
        public const string SmtpPort = nameof(SmtpPort);
        public const string SmtpEnableSsl = nameof(SmtpEnableSsl);
        public const string SmtpDeliveryMethod = nameof(SmtpDeliveryMethod);
        public const string SmtpFrom = nameof(MailSettings);
        public const string SmtpSpecifiedPickupDirectoryLocation = nameof(SmtpSpecifiedPickupDirectoryLocation);
    }

    #region Custom Claim Types

    public class CustomClaimTypes
    {
        public const string CustomerId = nameof(CustomerId);
        public const string CustomerName = nameof(CustomerName);
        public const string Email = nameof(Email);
    }

    #endregion
}
