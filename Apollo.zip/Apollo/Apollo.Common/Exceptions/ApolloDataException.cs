﻿using System;

namespace Apollo.Common.Exceptions
{
    public class ApolloDataException : Exception
    {
        public ApolloDataException() { }
        public ApolloDataException(string message) : base(message) { }
        public ApolloDataException(string message, Exception innerException) : base(message, innerException) { }
    }
}
