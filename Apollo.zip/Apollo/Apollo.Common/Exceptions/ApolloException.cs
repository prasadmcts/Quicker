﻿using System;

namespace Apollo.Common.Exceptions
{
    public class ApolloException : Exception
    {
        public ApolloException() { }
        public ApolloException(string message) : base(message) { }
        public ApolloException(string message, Exception innerException) : base(message, innerException) { }
    }
}