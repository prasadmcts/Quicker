﻿using System;

namespace Apollo.Common.Exceptions
{
    public class ApolloBusinessException : Exception
    {
        public ApolloBusinessException() { }
        public ApolloBusinessException(string message) : base(message) { }
        public ApolloBusinessException(string message, Exception innerException) : base(message, innerException) { }
    }
}
