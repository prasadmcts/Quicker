﻿namespace Apollo.Common.Enums
{
    public enum EmailStatus
    {
        None = 0,
        New = 1 << 0,
        Moved = 1 << 1,
        Assigned = 1 << 2,
        Rejected = 1 << 3,
        Deleted = 1 << 4
    }

    public enum DayofWeek
    {
        Sunday = 1,
        Monday,
        Tuesday,
        Wednesday,
        Thursday,
        Friday,
        Saturday
    }
    public enum DbActions
    {
        Add,
        Update,
        Delete
    }

    public enum DatabaseName
    {
        Apollo,
        Master
    }

    public enum Frequency
    {
        None = 0,
        Seconds = 1,
        Minutes = 2,
        Hours = 3,
        Days = 4,
        Weeks = 5,
        Months = 6,
        Years = 7
    }

    #region Master

    public enum ERole
    {
        Common = 1,
        Administrator = 2
    }

    #endregion
}
