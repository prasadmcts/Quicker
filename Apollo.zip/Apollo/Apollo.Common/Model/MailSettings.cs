﻿using System.Net.Mail;

namespace Apollo.Common.Model
{
    /*<smtp deliveryMethod="SpecifiedPickupDirectory" from="prasadmcts@gmail.com">
      <specifiedPickupDirectory pickupDirectoryLocation = "C:\\Temp\\" />
      <network host="gmail.com" port="25" enableSsl="false" />
    </smtp>*/
    public class MailSettings
    {
        public string SmtpHost { get; set; }
        public int SmtpPort { get; set; }
        public bool SmtpEnableSsl { get; set; }
        public SmtpDeliveryMethod SmtpDeliveryMethod { get; set; }
        public string SmtpFrom { get; set; }
        public string SmtpSpecifiedPickupDirectoryLocation { get; set; }
    }
}
