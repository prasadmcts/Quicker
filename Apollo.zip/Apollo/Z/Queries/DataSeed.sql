USE [Apollo]
GO

INSERT INTO [dbo].[Employer] ([Id], [CreatedBy], [CreatedDate], [ModifiedBy], [ModifiedDate], [Name], [Active], [Pin], [IsDeleted])
     VALUES (NEWID(), 'Prasad', GETDATE(), 'Prasad', GETDATE(), 'ANZ', 1, 12345, 0)
GO

DECLARE @EmployerId uniqueidentifier;
SET @EmployerId = (SELECT TOP 1 Id FROM [Employer])

INSERT INTO [dbo].[Employee] ([Id], [CreatedBy], [CreatedDate], [ModifiedBy], [ModifiedDate], [Name], [Active], [Pin], [EmployerId], [IsDeleted])
     VALUES
           (NEWID(), 'Prasad', GETDATE(), 'Prasad', GETDATE(), 'Prasad Kanaparthi', 1, 1, @EmployerId, 0)
GO


USE MyMaster

insert into [User] values (newid(), 'Prasad', GETDATE(), 'Prasad', GETDATE(), 0, 'admin@admin.com', 'ADQJO8iE+MQfSENQPUn6VChqI9ayJ0lg/Ud46MsZ64rytbLC9er6wjIUXZBjv0gRKA==')  -- 12345678
insert into [User] values (newid(), 'Prasad', GETDATE(), 'Prasad', GETDATE(), 0, 'common@common.com', 'AG2vhVAQKE/QlVkzu9wFU8zCqm7SS0m8LmIgOfMTl15t/lgJy7IpjXGQVJ660/gATQ==')  -- 12345678

insert into [Role] values (newid(), 'Prasad', GETDATE(), 'Prasad', GETDATE(), 0, 'Administrator')
insert into [Role] values (newid(), 'Prasad', GETDATE(), 'Prasad', GETDATE(), 0, 'Common')

select * from [User]
select * from [Role]
select * from UserRole
insert into UserRole values (newid(), 'Prasad', GETDATE(), 'Prasad', GETDATE(), 0, '687CF4E6-9F94-42CB-9240-1190D056FEEE', 'D24249D1-316D-409D-8551-80BC82A5C3DB')
insert into UserRole values (newid(), 'Prasad', GETDATE(), 'Prasad', GETDATE(), 0, '965D28C5-2FED-42C5-9AAE-22107F9121A5', 'B811CF67-BEAC-4202-9B64-79DD96AE075C')