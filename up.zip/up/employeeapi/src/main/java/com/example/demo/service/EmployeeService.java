package com.example.demo.service;

import com.example.demo.dto.EmployeeDTO;
import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j  // Lombok annotation to create an SLF4J logger
@Service
public class EmployeeService implements IEmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public Employee createEmployee(EmployeeDTO employeeDTO) {
        Employee emp = Employee.builder()
                .firstName(employeeDTO.getFirstName())
                .lastName(employeeDTO.getLastName())
                .city(employeeDTO.getCity())
                .dob(employeeDTO.getDob())
                .isActive(employeeDTO.getIsActive())
                .build();
        return employeeRepository.save(emp);
    }

    public List<Employee> getAllEmployees() {
        log.info("Working");
        return employeeRepository.findAll();
    }

    public Employee getEmployeeById(Long id) {
        return employeeRepository.findById(id).orElse(null);
    }

    public Employee updateEmployee(Long id, EmployeeDTO employeeDTO) {
        if (employeeRepository.existsById(id)) {
            Employee emp = Employee.builder()
                    .id(employeeDTO.getId())
                    .firstName(employeeDTO.getFirstName())
                    .lastName(employeeDTO.getLastName())
                    .city(employeeDTO.getCity())
                    .dob(employeeDTO.getDob())
                    .isActive(employeeDTO.getIsActive())
                    .build();
            return employeeRepository.save(emp);
        }
        return null; // or throw an exception
    }

    public boolean deleteEmployee(Long id) {
        if (employeeRepository.existsById(id)) {
            employeeRepository.deleteById(id);
            return true;
        }
        return false; // or throw an exception
    }
}