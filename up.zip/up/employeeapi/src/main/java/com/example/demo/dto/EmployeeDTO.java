package com.example.demo.dto;

import lombok.*;
import java.sql.Timestamp;

@Data
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeDTO {
    private Long id;
    private String firstName;
    private String lastName;
    private String city;
    private Timestamp dob;
    private Boolean isActive;
}