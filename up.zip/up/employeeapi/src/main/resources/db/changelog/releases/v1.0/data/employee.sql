INSERT INTO Employee (First_Name, Last_Name, City, DOB, Is_Active)
VALUES ('Foo', 'Boo', 'Bangalore', CURRENT_TIMESTAMP, 1);
INSERT INTO Employee (First_Name, Last_Name, City, DOB, Is_Active)
VALUES ('Scott', 'Matt', 'Mysore', CURRENT_TIMESTAMP, 1);