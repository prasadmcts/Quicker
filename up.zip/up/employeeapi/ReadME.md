TODO:

Mapper

Interfaces -- Done

Request Payload Validation

Authentication and Authorization

Calling another API's - Polly

Exception Handling

Cleanup resource files and DEV env - SQL/postgress

Unit Testing