let { baseRepository } = require('./baseRepository');

module.exports = {
    baseRepository
}