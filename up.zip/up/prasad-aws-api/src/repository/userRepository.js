const { userModel } = require('../models')
let { baseRepository } = require("./genericRepository");

baseRepository = baseRepository(userModel);

const getByEmail = async (email) => await baseRepository.getByObject({ email });

const getByType = async (type) => await baseRepository.getByObject({ type })

module.exports = {
  ...baseRepository,

  getByEmail,
  getByType
}