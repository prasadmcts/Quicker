const userRepository = require('./userRepository');

module.exports = {
    userRepository
}