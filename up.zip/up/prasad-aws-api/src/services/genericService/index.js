let { baseService } = require('./baseService')

module.exports = {
    baseService
}