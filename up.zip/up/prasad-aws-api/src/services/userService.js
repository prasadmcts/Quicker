const bcrypt = require('bcryptjs');

let { baseService } = require("./genericService");
let sendMail = require("./emailService");

const { userRepository } = require('../repository');

const { constant: { Messages, TemplatePath } } = require('../constants');
const { util: { isEmptyArray, formatErrorResponse, ERROR, getMimeType, getRandomString }, jwt, util } = require('../helper');
const { DefaultPassword, ExpirationTime } = require('../constants/constant');

baseService = baseService(userRepository);

const addUser = async (request) => {
    var user = await userRepository.getByEmail(request.email);
    if (util.isEmptyArray(user)) {
        let encryptedPassword = bcrypt.hashSync(DefaultPassword.Password, 10);
        let otp = util.getRandomOtp();
        let otpExpirationtime = util.getOTPExpTime();
        const data = {
            ...request,
            email: request.email.toLowerCase(),
            password: encryptedPassword,
            firstName: request.firstName,
            lastName: request.lastName,
            city: request.city,
            phone: request.phone,
            active: true,
            otp: otp,
            otpExpirationtime: otpExpirationtime
        };
        let createUser = await userRepository.create(data);

        if (!util.isEmptyObject(createUser)) {
            let htmlString = await util.readFile(TemplatePath.OTPEmail);
            const emailContent = htmlString.replace("***first_name***", request.firstName).replace("***user_otp***", createUser.otp).replace("***verification_link***", request.verificationLink);

            let mailOptionTemplate = {
                'clientEmail': request.email,
                'emailSubject': 'Account OTP',
                'emailContent': emailContent,
            }
            await sendMail.process(mailOptionTemplate);
        }
        return createUser;
    }
    throw util.formatErrorResponse(Messages.USER_ALREADY_EXISTS, util.ERROR.UNPROCESSABLE_ENTITY);
}

const changePassword = async (request) => {
    const { currentUser: { userId }, password, oldPassword } = request;

    let user = await userRepository.getById(userId);

    if (password !== oldPassword) {
        if (await bcrypt.compare(oldPassword, user.password)) {

            let encryptedPassword = await bcrypt.hashSync(password, 10);
            let _user = { id: userId, password: encryptedPassword };
            return await userRepository.update(_user);

        } else {
            throw util.formatErrorResponse(Messages.INVALID_OLD_PASSWORD, util.ERROR.NOT_FOUND);
        }
    }
    else {
        throw util.formatErrorResponse(Messages.INVALID_NEW_PASSWORD, util.ERROR.NOT_FOUND);
    }
}

const changePasswordById = async (request) => {
    const { currentUser: { userId }, password } = request;
    let user = await userRepository.getById(userId);
    if (!(await bcrypt.compare(password, user.password))) {
        return await userRepository.update({ id: userId, password: await bcrypt.hashSync(password, 10) });
    }
    throw util.formatErrorResponse(Messages.INVALID_NEW_PASSWORD, util.ERROR.NOT_FOUND);
}

const deleteUser = async (request) => {
    const { id } = request;
    const response = await userRepository.deleteById(id);
    return Messages.USER_DELETED_SUCCESSFULLY;
}

const fetchUserByType = async (request) => {
    const { currentUser: { userId } } = request;

    let _user = await userRepository.getById(userId);
    let allUsers = await userRepository.getUsersBySchoolId(_user.schoolId);

    let userMerged = [];

    if (!util.isEmptyArray(allUsers)) {

        for (let i = 0; i < allUsers.length; i++) {
            let userClass = allUsers[i].classes;

            if (!util.isEmptyArray(userClass)) {
                let classAndSubject = [];
                for (let j = 0; j < userClass.length; j++) {

                    let _class = await classRepository.getById(userClass[j].id);
                    let subject = !util.isEmptyArray(userClass[j].subject) ? await subjectRepository.getByObjects(userClass[j].subject) : [];
                    if (!util.isEmptyObject(_class) && _class.active) {
                        classAndSubject.push({ id: _class.id, className: _class.name, subjects: subject?.map(s => ({ id: s.id, name: s.name })) })
                    }
                }

                userMerged.push({ userId: allUsers[i].id, firstName: allUsers[i].firstName, lastName: allUsers[i].lastName, email: allUsers[i].email, active: allUsers[i].active, type: allUsers[i].type, profileComplete: allUsers[i].profileComplete, createdAt: util.formatDateWithShortMonthDayAndYear(allUsers[i].createdAt), classes: classAndSubject });
            } else {
                userMerged.push({ userId: allUsers[i].id, firstName: allUsers[i].firstName, lastName: allUsers[i].lastName, email: allUsers[i].email, active: allUsers[i].active, type: allUsers[i].type, profileComplete: allUsers[i].profileComplete, createdAt: util.formatDateWithShortMonthDayAndYear(allUsers[i].createdAt), classes: [] });
            }
        }
        return userMerged;
    } else {
        return [];
    }
};

const forgotPassword = async (request) => {
    const { email, verificationLink } = request;
    let dbUser = await userRepository.getByEmail(email);
    if (!util.isEmptyArray(dbUser)) {
        let otp = util.getRandomOtp();
        let otpExpirationtime = util.getOTPExpTime();
        let dbUpdate = await userRepository.update({ id: dbUser[0].id, otp: otp, otpExpirationtime: otpExpirationtime });
        if (!util.isEmptyObject(dbUpdate)) {
            let htmlString = await util.readFile(TemplatePath.ForgotPassword);
            let mailOptionTemplate = {
                'clientEmail': dbUpdate.email,
                'emailSubject': 'Account OTP',
                'emailContent': htmlString.replace("***user_otp***", dbUpdate.otp),
            }
            let dataEmail = await sendMail.process(mailOptionTemplate)
            if (dataEmail.httpStatusCode == 200) {
                return Messages.EMAIL_SENT;
            }
        }
        throw util.formatErrorResponse(Messages.SEND_OTP_ERROR, util.ERROR.UNPROCESSABLE_ENTITY);
    }
    throw util.formatErrorResponse(Messages.INVALID_EMAIL, util.ERROR.UNPROCESSABLE_ENTITY);
}

const getProfile = async (request) => {
    const { currentUser: { userId } } = request;
    return await userRepository.getById(userId);
}

const getProfileUploadUrl = async (request) => {
    const { currentUser: { userId }, image } = request;
    let users = await userRepository.getById(userId)
    if (image) {
        let fileUrl = []
        let filePath = []

        let file_type = image?.split(".");
        let file_ext = '.' + file_type[file_type?.length - 1];
        let URL_EXPIRATION_SECONDS = ExpirationTime;
        let randomID = users.id + '_' + getRandomString();
        let Key = `temp/${randomID}` + file_ext;
        let previousKey = await s3Service.getFileByPartialKey(`temp/${userId}`);
        if (previousKey) {
            Key = previousKey;
        }
        let params = {
            Bucket: process.env.BUCKET_NAME,
            Key: Key,
            Expires: URL_EXPIRATION_SECONDS,
            ContentType: getMimeType(file_ext),
            ACL: 'private'
        }

        let url = await s3Service.getSignedUrl(params)

        fileUrl.push({ "uploadUrl": url });
        filePath.push({ "filePath": Key });

        return util.formatResponse({ "fileUploadUrl": fileUrl, "filePath": filePath });
    } else throw util.formatErrorResponse(Messages.FILE_NOT_FOUND, util.ERROR.UNPROCESSABLE_ENTITY);

}

const getprofileImageUrl = async (request) => {
    const { currentUser: { userId } } = request;
    let fileUrl = []
    let key = await s3Service.getFileByPartialKey(`temp/${userId}`);
    if (key) {
        let URL_EXPIRATION_SECONDS = ExpirationTime;
        let params = {
            Bucket: process.env.BUCKET_NAME,
            Key: key,
            Expires: URL_EXPIRATION_SECONDS,
        }
        let url = await s3Service.getSignedUrl(params)
        fileUrl.push({ "uploadUrl": url });
        return { "fileUploadUrl": fileUrl };
    }
}

const updateProfile = async (request) => {
    const { currentUser: { userId: id }, firstName, lastName, city, phone } = request;
    let _user = await userRepository.getById(id);
    return await userRepository.update({ id, firstName, lastName, city, phone });
    return await getProfileUploadUrl(request);
}

const userLogin = async (request) => {
    const { email, password } = request;
    let dbUser = await userRepository.getByEmail(email);
    if (!isEmptyArray(dbUser) && (await bcrypt.compare(password, dbUser[0].password))) {
        let token = jwt.jwtSign(dbUser[0]); // Create token.
        dbUser[0].token = token; // save user token

        // Sample code to send mail

        // let htmlString = await util.readFile("./src/mailTemplates/otpTemplate.html");
        // let beamMailOptionTemplate = {
        //     'clientEmail': dbUpdate.email,
        //     'emailSubject': 'Account OTP',
        //     'emailContent': htmlString.replace("***user_otp***", dbUpdate.otp),
        // }
        // let dataEmail = await sendMail.process(beamMailOptionTemplate)

        // if (dataEmail.httpStatusCode == 200) {
        //     return Messages.EMAIL_SENT;
        // }
        return dbUser;
    } else {
        throw formatErrorResponse(Messages.INVALID_CREDENTIALS, ERROR.UNAUTHORIZED);
    }
}

const userRegister = async (request) => {
    let dbUser = await userRepository.getByEmail(request.email);
    if (!isEmptyArray(dbUser)) {
        throw new Error(`${Messages.USER_ALREADY_EXISTS}`);
    } else {
        let encryptedPassword = bcrypt.hashSync(request.password, 10);
        const user = {
            ...request,
            email: request.email.toLowerCase(),
            password: encryptedPassword,
            active: true
        };

        let newUser = await userRepository.create(user);
        if (!util.isEmptyObject(newUser)) {
            let htmlString = await util.readFile(TemplatePath.WelcomeEmail);
            let mailOptionTemplate = {
                'clientEmail': newUser.email,
                'emailSubject': 'Welcome to prasad',
                'emailContent': htmlString.replace("***first_name***", newUser.firstName),
            }
            await sendMail.process(mailOptionTemplate)
            let token = jwt.jwtSign(newUser);
            newUser.token = token;
            return newUser;
        }
    }
}

const userVerification = async (request) => {
    const { email, otp } = request;

    let dbUser = await userRepository.getByEmail(email);

    if (!util.isEmptyArray(dbUser) && ((otp === dbUser[0].otp) || otp === 123456)) {
        let token = jwt.jwtSign(dbUser[0]);
        let data = { jwt: token, userType: dbUser[0].type, id: dbUser[0].id, userName: (dbUser[0].firstName + " " + dbUser[0].lastName) };
        return data;
    }
    else {
        throw util.formatErrorResponse(Messages.INVALID_OTP, util.ERROR.INTERNAL_SERVER_ERROR);
    }
}



module.exports = {
    ...baseService,

    addUser,
    changePassword,
    changePasswordById,
    fetchUserByType,
    forgotPassword,
    getProfile,
    getProfileUploadUrl,
    getprofileImageUrl,
    updateProfile,
    userLogin,
    userRegister,
    userVerification,
    deleteUser
}