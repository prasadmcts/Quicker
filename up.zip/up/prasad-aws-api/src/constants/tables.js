let DBEnvPrefix = process.env.DB_PREFIX;
let DBNamePrefix = `${DBEnvPrefix}template_`;

exports.TABLE_NAMES = {
    USER_TABLE: `${DBNamePrefix}user`
}