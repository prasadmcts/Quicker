exports.Indexes = {
    USER_EMAIL_INDEX: `email-index`
}