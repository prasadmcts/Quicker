exports.Messages = {
    ACCESS_DENIED: "Access Denied",
    ACCOUNT_INACTIVE: "Your Account is InActive",
    ACCOUNT_USER_DATABASE_ERROR: "Account User Database Error",
    APPLICATION_ERROR: "Something wrong while sending invitation request",
    DATABASE_ERROR: "Database Error",
    EMAIL_SENT: "Otp has been sent to mail",
}

exports.Label = {
    Active: "Active",
    City: "City",
    Country: "Country",
    Email: "Email",
    Female: "Female",
    FirstName: "First Name",
    LastName: "Last Name"
}

exports.Environment = {
    Development: "development"
}

exports.KeyWords = {
    EMAIL: "User Email",
    PASSWORD: "User Password",
    STATUS: "Status",
    USER_ID: "User ID",
    SUCCESS: "success",
    VERIFIED: "verified",
    NAME: "name"
}

exports.RegexFormat = {
    Password: "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])"
}

exports.Roles = {
    None: 0,
    User: 1,
    Admin: 2,
    SuperAdmin: 4
};

exports.TemplatePath = {
    WelcomeEmail: "./src/mailTemplates/welcomeEmail.html"
}

exports.UserStatus = {
    Active: "Active",
    InActive: "InActive"
}

exports.DefaultPassword = {
    Password: "123Pa$$word!"
}

exports.ExpirationTime = 86400