const auth = require('./auth')
const validator = require('./validator')

module.exports = {
    auth,
    validator
}