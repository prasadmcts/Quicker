const commonController = require('./commonController')
const userController = require('./userController')

module.exports = {
    commonController,
    userController
}