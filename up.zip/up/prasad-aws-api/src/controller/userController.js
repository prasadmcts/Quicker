let { baseController } = require("./genericController");
const { userService } = require("../services");

baseController = baseController(userService);

const addUser = async (req, res, next) => {
    try {
        let request = req.body;
        let result = await userService.addUser(request);
        res.send(result);
    } catch (error) {
        next(error);
    }
};

const changePassword = async (req, res, next) => {
    try {
        let request = req.body;
        let result = await userService.changePassword(request);
        res.send(result);
    } catch (error) {
        next(error);
    }
};

const changePasswordById = async (req, res, next) => {
    try {
        let request = req.body;
        let result = await userService.changePasswordById(request);
        res.send(result);
    } catch (error) {
        next(error);
    }
};

const deleteUser = async (req, res, next) => {
    try {
        let request = req.body;
        let result = await userService.deleteUser(request);
        res.send(result);
    } catch (error) {
        next(error);
    }
};

const fetchUserByType = async (req, res, next) => {
    try {
        let request = req.body;
        let result = await userService.fetchUserByType(request);
        res.send(result);
    } catch (error) {
        next(error);
    }
};

const forgotPassword = async (req, res, next) => {
    try {
        let request = req.body;
        let result = await userService.forgotPassword(request);
        res.send(result);
    } catch (error) {
        next(error);
    }
};

const getProfile = async (req, res, next) => {
    try {
        let request = req.body;
        let result = await userService.getProfile(request);
        res.send(result);
    } catch (error) {
        next(error);
    }
};

const getProfileUploadUrl = async (req, res, next) => {
    try {
        let request = req.body;
        let result = await userService.getProfileUploadUrl(request);
        res.send(result);
    } catch (error) {
        next(error);
    }
};

const getprofileImageUrl = async (req, res, next) => {
    try {
        let request = req.body;
        let result = await userService.getprofileImageUrl(request);
        res.send(result);
    } catch (error) {
        next(error);
    }
};

const inviteUser = async (req, res, next) => {
    try {
        let request = req.body;
        let result = await userService.inviteUser(request);
        res.send(result);
    } catch (error) {
        next(error);
    }
};

const updateProfile = async (req, res, next) => {
    try {
        let request = req.body;
        let result = await userService.updateProfile(request);
        res.send(result);
    } catch (error) {
        next(error);
    }
};

const userLogin = async (req, res, next) => {
    try {
        let request = req.body;
        let result = await userService.userLogin(request);
        res.send(result);
    } catch (error) {
        next(error);
    }
};

const userRegister = async (req, res, next) => {
    try {
        let request = req.body;
        let result = await userService.userRegister(request);
        res.send(result);
    } catch (error) {
        next(error);
    }
};

const userVerification = async (req, res, next) => {
    try {
        let request = req.body;
        let result = await userService.userVerification(request);
        res.send(result);
    } catch (error) {
        next(error);
    }
};


module.exports = {
    ...baseController,
    
    addUser,
    changePassword,
    changePasswordById,
    deleteUser,
    fetchUserByType,
    forgotPassword,
    getProfile,
    getProfileUploadUrl,
    getprofileImageUrl,
    inviteUser,
    updateProfile,
    userLogin,
    userRegister,
    userVerification,
}