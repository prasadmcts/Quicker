let { baseController } = require('./baseController')

module.exports = {
    baseController
}