const dynamoose = require("dynamoose");
const { v4: uuidv4 } = require('uuid');
const { tables: { TABLE_NAMES }, indexes } = require('../constants');

const schema = new dynamoose.Schema(
    {
        "id": { type: String, default: () => uuidv4(), hashKey: true },
        "firstName": { type: String },
        "lastName": { type: String },
        "email": {
            type: String,
            index: {
                "global": true,
                "name": "email-index"
            }
        },
        "password": { type: String },
        "phone": { type: String },
        "city": { type: String },
        "type": { type: Number },
        "otp": { type: Number },
        "active": { type: Boolean },
    },
    {
        "timestamps": true
    }
);

const userModel = dynamoose.model(TABLE_NAMES.USER_TABLE, schema, {
    create: true,
    throughput: "ON_DEMAND",
});

module.exports = userModel;