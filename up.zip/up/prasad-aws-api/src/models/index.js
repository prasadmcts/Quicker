const userModel = require('./userModel')

module.exports = {
    userModel
}