const baseRepository = (model) => {

    const create = async (item) => await model.create(item);

    const createMany = async (items) => await model.bulkCreate(items);

    const deleteById = async (id) => await model.destroy({
        where: {
          id: id,
        }
      });

    const deleteByObject = async (object) => await model.destroy({
        where: object,
      });

    const deleteMany = async (ids) => await model.destroy({
        where: {
          id: ids
        }
      });

    const getAll = async () => await model.findAll();

    const getById = async (id) => await model.findByPk(id);

    const getByObject = async (object) => await model.findAll({
        where: object,
      });

    const getByObjects = async (objects, attributes) => await console.log("TODO"); // [1, 2]  or [{"id": 1}, {"id": 2}] or [{"id": 1, "name": "Tim"}, {"id": 2, "name": "Charlie"}]

    const query = async (request) => {
        const { queryToExec, QueryType } = request;
        return await sequelize.query(queryToExec, {
            type: QueryType,
          });;
    };

    const update = async (request) => {
        const { id, ...data } = request;
        return await model.update({ ...data },{
            where: { id },
          },);
    }

    const updateMany = async (items) => await console.log("TODO");

    return {
        create,
        createMany,

        deleteById,
        deleteByObject,
        deleteMany,

        getAll,
        getById,
        getByObject,
        getByObjects, // TODO

        query,

        update,
        updateMany // TODO
    };
};

module.exports.baseRepository = baseRepository;