const DataTypes = require('sequelize');
const sequelize  = require('../../dbConfig');
const { tables: { TABLE_NAMES } } = require('../constants');

const schema = {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    firstName: {
        type: DataTypes.STRING(255),
        allowNull: false,
    },
    lastName: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    email: {
        type: DataTypes.STRING(255),
        allowNull: false,
        unique:true
    },
    password: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    phone: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    city: {
        type: DataTypes.STRING(50),
        allowNull: false,
    },
}

const userModel = sequelize.define(TABLE_NAMES.USER_TABLE, schema, { timestamps: true });

module.exports = userModel;