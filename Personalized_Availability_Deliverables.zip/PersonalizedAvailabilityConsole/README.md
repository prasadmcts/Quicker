# Personalized Availability Console

A small runnable Spring Boot console project demonstrating weekly interviewer preference rules with an Entity, Spring Data JPA repositories, a JPQL query, a service, sample data, and tests.

**Scope:** This project computes personalised slot start/end times only. It does not integrate with any calendar provider or perform bookings.

## Requirements

- JDK 17 or later
- Maven 3.6.3 or later
- Internet access on first build, so Maven can resolve dependencies

The project uses Spring Boot 3.5.16 and Java 17. See the official [Spring Boot documentation](https://docs.spring.io/spring-boot/) for compatible build/runtime details.

## Run the console demo

From the project root:

```bash
mvn spring-boot:run
```

The default profile uses an in-memory H2 database and loads `schema.sql` and `data.sql`. The console prints example slots for:

- Wednesday, 8 AM to 5 PM, with 2 PM to 4 PM blocked.
- Friday, 8 AM to 5 PM, using a 45-minute interview duration.
- A 60-minute interview with a 30-minute start-time step.

No Oracle database is needed to run the demo.

## Run tests

```bash
mvn test
```

## Project structure

```text
src/main/java/com/example/personalizedavailability/
  PersonalizedAvailabilityApplication.java
  console/AvailabilityConsoleRunner.java
  domain/InterviewerMaster.java
  domain/InterviewerMasterId.java
  domain/InterviewerPreferenceSlot.java
  domain/PreferenceRule.java
  domain/GeneratedInterviewSlot.java
  domain/SlotGenerationResult.java
  repository/InterviewerMasterRepository.java
  repository/InterviewerPreferenceSlotRepository.java
  service/InterviewerPreferenceService.java
  service/PreferenceSlotCalculator.java
src/main/resources/
  application.properties
  application-oracle.properties
  schema.sql
  data.sql
src/test/java/com/example/personalizedavailability/
  InterviewerPreferenceServiceIntegrationTest.java
sql/
  oracle_ddl.sql
  oracle_test_data_scenario_a.sql
  oracle_test_data_scenario_b.sql
  oracle_select_queries.sql
```

## Core rule semantics

- `PREFERENCE_ENABLED = 'N'`: preference rules are disabled. The service returns `preferencesConfigured=false`; callers can decide how to handle that state.
- `PREFERENCE_ENABLED = 'Y'`: the interviewer must have at least one preference row. If not, the service throws a configuration error instead of silently treating missing rows as unrestricted availability.
- For a selected weekday, a generated interview must fit entirely inside an `IS_AVAILABLE=1` interval.
- Any overlap with an `IS_AVAILABLE=0` interval blocks that candidate slot.
- Day of week: Monday=1 through Sunday=7.
- Times are integer minutes after midnight: 08:00=480, 14:00=840, 17:00=1020, end of day=1440.
- Default slot step equals the interview duration. An overload allows them to differ, for example 60-minute interviews starting every 30 minutes.
- The date passed to the service must be the selected date in the interviewer's local time zone. The timezone is read from `INTERVIEWER_MASTER` and used to create output `ZonedDateTime` values.
- Slot increments restart at the start of each effective allowed window after blocked windows are subtracted.

## Oracle adaptation

The Oracle scripts use `INTERVIEWER_MASTER` as a placeholder for your existing mapping table. Check that `(INTERVIEWER_SID, ORACLE_CAND_ID)` is a primary/unique key and that SID/candidate ID datatypes match exactly. The optional `PREFERENCE_ENABLED` column must be added to your real table if you adopt this configuration flag. If your existing table has additional required columns, adapt the sample parent inserts.

The project models `ORACLE_CAND_ID` as the second part of the interviewer mapping key, following the design assumption discussed during the design. If it identifies the candidate being interviewed, revise the preference key to be interviewer-based before deployment.

## Important production considerations

- Validate the maximum interview duration and allowed slot increment at the service/API boundary.
- Decide whether the business requires `slotStepMinutes == durationMinutes`; the demo supports both equal and different values.
- Avoid persisting generated slots; they are derived from recurring preference rules and a selected date/duration.
- Use a database transaction when saving preference rows and changing `PREFERENCE_ENABLED` so the flag and rules stay consistent.
- This demo contains no REST endpoint and no calendar integration by design.
