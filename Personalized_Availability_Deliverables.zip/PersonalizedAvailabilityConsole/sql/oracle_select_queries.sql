-- 1. Read saved weekly rules for one interviewer mapping.
SELECT DAY_OF_WEEK, START_MINUTE, END_MINUTE, IS_AVAILABLE
FROM INTERVIEWER_PREFERENCE_SLOT
WHERE INTERVIEWER_SID = :interviewerSid
  AND ORACLE_CAND_ID = :oracleCandId
ORDER BY DAY_OF_WEEK, START_MINUTE;

-- 2. Read preference enablement and time zone from the existing parent table.
SELECT PREFERENCE_ENABLED, TIME_ZONE
FROM INTERVIEWER_MASTER
WHERE INTERVIEWER_SID = :interviewerSid
  AND ORACLE_CAND_ID = :oracleCandId;

-- 3. Count preference rows to diagnose enabled-but-empty configuration.
SELECT COUNT(*) AS PREFERENCE_ROW_COUNT
FROM INTERVIEWER_PREFERENCE_SLOT
WHERE INTERVIEWER_SID = :interviewerSid
  AND ORACLE_CAND_ID = :oracleCandId;

-- 4. Read rules for a selected weekday (Monday=1 ... Sunday=7).
SELECT START_MINUTE, END_MINUTE, IS_AVAILABLE
FROM INTERVIEWER_PREFERENCE_SLOT
WHERE INTERVIEWER_SID = :interviewerSid
  AND ORACLE_CAND_ID = :oracleCandId
  AND DAY_OF_WEEK = :dayOfWeek
ORDER BY START_MINUTE;

-- Note: candidate start-time generation and blocked-window subtraction are done in Java,
-- because required interview duration and start-time increment are runtime inputs.
