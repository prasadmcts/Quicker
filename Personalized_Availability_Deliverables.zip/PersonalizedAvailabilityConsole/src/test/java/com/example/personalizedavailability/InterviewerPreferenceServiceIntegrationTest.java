package com.example.personalizedavailability;

import com.example.personalizedavailability.domain.InterviewerMaster;
import com.example.personalizedavailability.domain.InterviewerMasterId;
import com.example.personalizedavailability.domain.GeneratedInterviewSlot;
import com.example.personalizedavailability.domain.SlotGenerationResult;
import com.example.personalizedavailability.repository.InterviewerMasterRepository;
import com.example.personalizedavailability.service.InterviewerPreferenceService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class InterviewerPreferenceServiceIntegrationTest {

    @Autowired
    private InterviewerPreferenceService service;

    @Autowired
    private InterviewerMasterRepository masterRepository;

    @Test
    void generatesThirtyMinuteSlotsAndExcludesWednesdayBlockedWindow() {
        SlotGenerationResult result = service.generateSlots(
                "SID_B", "CAND_B", LocalDate.of(2026, 10, 28), 30);

        assertTrue(result.isPreferencesConfigured());
        assertEquals(14, result.getSlots().size());
        assertEquals(LocalTime.of(8, 0), result.getSlots().get(0).getStartDateTime().toLocalTime());
        assertEquals(LocalTime.of(13, 30), result.getSlots().get(11).getStartDateTime().toLocalTime());
        assertEquals(LocalTime.of(16, 0), result.getSlots().get(12).getStartDateTime().toLocalTime());
        assertEquals(LocalTime.of(16, 30), result.getSlots().get(13).getStartDateTime().toLocalTime());
        assertTrue(result.getSlots().stream().noneMatch(slot ->
                slot.getStartDateTime().toLocalTime().isBefore(LocalTime.of(16, 0))
                && slot.getEndDateTime().toLocalTime().isAfter(LocalTime.of(14, 0))));
    }

    @Test
    void supportsDurationDifferentFromSlotStep() {
        SlotGenerationResult result = service.generateSlots(
                "SID_B", "CAND_B", LocalDate.of(2026, 10, 28), 60, 30);

        assertEquals(12, result.getSlots().size());
        assertTrue(result.getSlots().stream().allMatch(slot ->
                java.time.Duration.between(slot.getStartDateTime(), slot.getEndDateTime()).toMinutes() == 60));
    }

    @Test
    void noRulesForSelectedWeekdayMeansNoSlotsButPreferencesAreConfigured() {
        SlotGenerationResult result = service.generateSlots(
                "SID_A", "CAND_A", LocalDate.of(2026, 10, 26), 30); // Monday
        assertTrue(result.isPreferencesConfigured());
        assertTrue(result.getSlots().isEmpty());
    }

    @Test
    void disabledPreferencesReturnNotConfigured() {
        SlotGenerationResult result = service.generateSlots(
                "SID_OFF", "CAND_OFF", LocalDate.of(2026, 10, 28), 30);
        assertFalse(result.isPreferencesConfigured());
        assertTrue(result.getSlots().isEmpty());
    }

    @Test
    void enabledButMissingPreferenceRowsIsConfigurationError() {
        InterviewerMaster master = new InterviewerMaster();
        master.setInterviewerSid("SID_EMPTY");
        master.setOracleCandId("CAND_EMPTY");
        master.setTimeZone("Asia/Kolkata");
        master.setPreferenceEnabled("Y");
        masterRepository.save(master);

        IllegalStateException ex = assertThrows(IllegalStateException.class, () ->
                service.generateSlots("SID_EMPTY", "CAND_EMPTY",
                        LocalDate.of(2026, 10, 28), 30));
        assertTrue(ex.getMessage().contains("no preference rows"));
    }
}
