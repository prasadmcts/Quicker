package com.example.personalizedavailability.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

@Entity
@Table(name = "INTERVIEWER_MASTER")
@IdClass(InterviewerMasterId.class)
public class InterviewerMaster {

    @Id
    @Column(name = "INTERVIEWER_SID", nullable = false, length = 100)
    private String interviewerSid;

    @Id
    @Column(name = "ORACLE_CAND_ID", nullable = false, length = 100)
    private String oracleCandId;

    @Column(name = "TIME_ZONE", nullable = false, length = 64)
    private String timeZone;

    @Column(name = "PREFERENCE_ENABLED", nullable = false, length = 1)
    private String preferenceEnabled;

    public InterviewerMaster() {
    }

    public String getInterviewerSid() { return interviewerSid; }
    public void setInterviewerSid(String interviewerSid) { this.interviewerSid = interviewerSid; }
    public String getOracleCandId() { return oracleCandId; }
    public void setOracleCandId(String oracleCandId) { this.oracleCandId = oracleCandId; }
    public String getTimeZone() { return timeZone; }
    public void setTimeZone(String timeZone) { this.timeZone = timeZone; }
    public String getPreferenceEnabled() { return preferenceEnabled; }
    public void setPreferenceEnabled(String preferenceEnabled) { this.preferenceEnabled = preferenceEnabled; }
}
