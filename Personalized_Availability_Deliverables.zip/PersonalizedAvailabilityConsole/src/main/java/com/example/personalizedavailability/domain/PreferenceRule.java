package com.example.personalizedavailability.domain;

/** Plain rule DTO used by the calculator, independent of JPA. */
public class PreferenceRule {
    private final int dayOfWeek;
    private final int startMinute;
    private final int endMinute;
    private final int isAvailable;

    public PreferenceRule(int dayOfWeek, int startMinute, int endMinute, int isAvailable) {
        this.dayOfWeek = dayOfWeek;
        this.startMinute = startMinute;
        this.endMinute = endMinute;
        this.isAvailable = isAvailable;
    }

    public int getDayOfWeek() { return dayOfWeek; }
    public int getStartMinute() { return startMinute; }
    public int getEndMinute() { return endMinute; }
    public int getIsAvailable() { return isAvailable; }
}
