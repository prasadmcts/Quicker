package com.example.personalizedavailability.console;

import com.example.personalizedavailability.domain.GeneratedInterviewSlot;
import com.example.personalizedavailability.domain.SlotGenerationResult;
import com.example.personalizedavailability.service.InterviewerPreferenceService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Component
public class AvailabilityConsoleRunner implements CommandLineRunner {

    private final InterviewerPreferenceService service;
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("h:mm a z");

    public AvailabilityConsoleRunner(InterviewerPreferenceService service) {
        this.service = service;
    }

    @Override
    public void run(String... args) {
        System.out.println();
        System.out.println("====================================================");
        System.out.println(" PERSONALIZED INTERVIEW AVAILABILITY - CONSOLE DEMO");
        System.out.println(" Preference rules only; no calendar integration");
        System.out.println("====================================================");

        printSlots("Use case B: Wednesday, 30-minute interviews",
                service.generateSlots("SID_B", "CAND_B",
                        LocalDate.of(2026, 10, 28), 30));

        printSlots("Use case B: Wednesday, 60-minute interview, 30-minute step",
                service.generateSlots("SID_B", "CAND_B",
                        LocalDate.of(2026, 10, 28), 60, 30));

        printSlots("Use case A: Friday, 45-minute interviews",
                service.generateSlots("SID_A", "CAND_A",
                        LocalDate.of(2026, 10, 30), 45));

        SlotGenerationResult disabled = service.generateSlots(
                "SID_OFF", "CAND_OFF", LocalDate.of(2026, 10, 28), 30);
        System.out.println("\nDisabled preferences example: preferencesConfigured="
                + disabled.isPreferencesConfigured() + ", slots=" + disabled.getSlots().size());
        System.out.println("====================================================\n");
    }

    private void printSlots(String title, SlotGenerationResult result) {
        System.out.println("\n" + title);
        System.out.println("Preferences configured: " + result.isPreferencesConfigured());
        if (result.getSlots().isEmpty()) {
            System.out.println("  (no eligible slots)");
            return;
        }
        for (GeneratedInterviewSlot slot : result.getSlots()) {
            System.out.printf("  %s - %s%n",
                    TIME_FORMAT.format(slot.getStartDateTime()),
                    TIME_FORMAT.format(slot.getEndDateTime()));
        }
        System.out.println("Total slots: " + result.getSlots().size());
    }
}
