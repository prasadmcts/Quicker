package com.example.personalizedavailability.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.LocalDateTime;

@Entity
@Table(name = "INTERVIEWER_PREFERENCE_SLOT")
public class InterviewerPreferenceSlot {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SLOT_ID")
    private Long slotId;

    @Column(name = "INTERVIEWER_SID", nullable = false, length = 100)
    private String interviewerSid;

    @Column(name = "ORACLE_CAND_ID", nullable = false, length = 100)
    private String oracleCandId;

    @Column(name = "DAY_OF_WEEK", nullable = false)
    private Integer dayOfWeek;

    @Column(name = "START_MINUTE", nullable = false)
    private Integer startMinute;

    @Column(name = "END_MINUTE", nullable = false)
    private Integer endMinute;

    @Column(name = "IS_AVAILABLE", nullable = false)
    private Integer availableFlag;

    @Column(name = "CREATED_AT", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "UPDATED_AT", nullable = false)
    private LocalDateTime updatedAt;

    protected InterviewerPreferenceSlot() {
    }

    public Long getSlotId() { return slotId; }
    public String getInterviewerSid() { return interviewerSid; }
    public String getOracleCandId() { return oracleCandId; }
    public Integer getDayOfWeek() { return dayOfWeek; }
    public Integer getStartMinute() { return startMinute; }
    public Integer getEndMinute() { return endMinute; }
    public Integer getAvailableFlag() { return availableFlag; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
}
