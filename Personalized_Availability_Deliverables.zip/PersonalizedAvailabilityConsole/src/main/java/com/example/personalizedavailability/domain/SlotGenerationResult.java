package com.example.personalizedavailability.domain;

import java.util.List;

public class SlotGenerationResult {
    private final boolean preferencesConfigured;
    private final List<GeneratedInterviewSlot> slots;

    public SlotGenerationResult(boolean preferencesConfigured, List<GeneratedInterviewSlot> slots) {
        this.preferencesConfigured = preferencesConfigured;
        this.slots = List.copyOf(slots);
    }

    public boolean isPreferencesConfigured() { return preferencesConfigured; }
    public List<GeneratedInterviewSlot> getSlots() { return slots; }
}
