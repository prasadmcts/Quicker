package com.example.personalizedavailability.service;

import com.example.personalizedavailability.domain.GeneratedInterviewSlot;
import com.example.personalizedavailability.domain.InterviewerMaster;
import com.example.personalizedavailability.domain.InterviewerPreferenceSlot;
import com.example.personalizedavailability.domain.PreferenceRule;
import com.example.personalizedavailability.domain.SlotGenerationResult;
import com.example.personalizedavailability.repository.InterviewerMasterRepository;
import com.example.personalizedavailability.repository.InterviewerPreferenceSlotRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class InterviewerPreferenceService {

    private final InterviewerMasterRepository masterRepository;
    private final InterviewerPreferenceSlotRepository slotRepository;
    private final PreferenceSlotCalculator calculator = new PreferenceSlotCalculator();

    public InterviewerPreferenceService(
            InterviewerMasterRepository masterRepository,
            InterviewerPreferenceSlotRepository slotRepository) {
        this.masterRepository = masterRepository;
        this.slotRepository = slotRepository;
    }

    /** Default: start-time increment equals interview duration. */
    @Transactional(readOnly = true)
    public SlotGenerationResult generateSlots(
            String interviewerSid,
            String oracleCandId,
            LocalDate interviewerLocalDate,
            int durationMinutes) {
        return generateSlots(interviewerSid, oracleCandId, interviewerLocalDate,
                durationMinutes, durationMinutes);
    }

    /**
     * Generate allowed personalised slots for a selected local date.
     * The date is interpreted in the interviewer's configured time zone.
     */
    @Transactional(readOnly = true)
    public SlotGenerationResult generateSlots(
            String interviewerSid,
            String oracleCandId,
            LocalDate interviewerLocalDate,
            int durationMinutes,
            int slotStepMinutes) {

        if (interviewerLocalDate == null) {
            throw new IllegalArgumentException("interviewerLocalDate is required");
        }
        if (durationMinutes <= 0 || slotStepMinutes <= 0) {
            throw new IllegalArgumentException("Duration and slot increment must be positive");
        }

        InterviewerMaster master = masterRepository
                .findByInterviewerSidAndOracleCandId(interviewerSid, oracleCandId)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Interviewer mapping not found for the supplied SID and Oracle candidate ID"));

        if ("N".equalsIgnoreCase(master.getPreferenceEnabled())) {
            return new SlotGenerationResult(false, List.of());
        }
        if (!"Y".equalsIgnoreCase(master.getPreferenceEnabled())) {
            throw new IllegalStateException("PREFERENCE_ENABLED must be Y or N");
        }

        List<InterviewerPreferenceSlot> entities = slotRepository
                .findWeeklyPreferences(interviewerSid, oracleCandId);

        if (entities.isEmpty()) {
            throw new IllegalStateException(
                    "Preferences are enabled but no preference rows exist for this interviewer mapping");
        }

        final ZoneId timeZone;
        try {
            timeZone = ZoneId.of(master.getTimeZone());
        } catch (DateTimeException ex) {
            throw new IllegalStateException("Invalid interviewer time zone: " + master.getTimeZone(), ex);
        }

        List<PreferenceRule> rules = entities.stream()
                .map(entity -> new PreferenceRule(
                        entity.getDayOfWeek(),
                        entity.getStartMinute(),
                        entity.getEndMinute(),
                        entity.getAvailableFlag()))
                .collect(Collectors.toList());

        List<GeneratedInterviewSlot> slots = calculator.calculate(
                rules, interviewerLocalDate, timeZone, durationMinutes, slotStepMinutes);

        return new SlotGenerationResult(true, slots);
    }
}
