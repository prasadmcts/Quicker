package com.example.personalizedavailability.repository;

import com.example.personalizedavailability.domain.InterviewerMaster;
import com.example.personalizedavailability.domain.InterviewerMasterId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface InterviewerMasterRepository
        extends JpaRepository<InterviewerMaster, InterviewerMasterId> {

    Optional<InterviewerMaster> findByInterviewerSidAndOracleCandId(
            String interviewerSid, String oracleCandId);
}
