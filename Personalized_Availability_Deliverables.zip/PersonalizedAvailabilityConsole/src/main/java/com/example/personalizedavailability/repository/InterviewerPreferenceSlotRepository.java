package com.example.personalizedavailability.repository;

import com.example.personalizedavailability.domain.InterviewerPreferenceSlot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface InterviewerPreferenceSlotRepository
        extends JpaRepository<InterviewerPreferenceSlot, Long> {

    /** JPQL uses entity and Java attribute names, not physical database column names. */
    @Query("SELECT p FROM InterviewerPreferenceSlot p " +
           "WHERE p.interviewerSid = :interviewerSid " +
           "AND p.oracleCandId = :oracleCandId " +
           "ORDER BY p.dayOfWeek, p.startMinute")
    List<InterviewerPreferenceSlot> findWeeklyPreferences(
            @Param("interviewerSid") String interviewerSid,
            @Param("oracleCandId") String oracleCandId);
}
