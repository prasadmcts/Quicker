package com.example.personalizedavailability.domain;

import java.time.ZonedDateTime;

public class GeneratedInterviewSlot {
    private final ZonedDateTime startDateTime;
    private final ZonedDateTime endDateTime;

    public GeneratedInterviewSlot(ZonedDateTime startDateTime, ZonedDateTime endDateTime) {
        this.startDateTime = startDateTime;
        this.endDateTime = endDateTime;
    }

    public ZonedDateTime getStartDateTime() { return startDateTime; }
    public ZonedDateTime getEndDateTime() { return endDateTime; }
}
