package com.example.personalizedavailability.service;

import com.example.personalizedavailability.domain.GeneratedInterviewSlot;
import com.example.personalizedavailability.domain.PreferenceRule;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/** Pure Java calculation: no Spring or JPA dependencies. */
public class PreferenceSlotCalculator {

    public List<GeneratedInterviewSlot> calculate(
            List<PreferenceRule> weeklyRules,
            LocalDate interviewerLocalDate,
            ZoneId timeZone,
            int durationMinutes,
            int slotStepMinutes) {

        if (durationMinutes <= 0) {
            throw new IllegalArgumentException("durationMinutes must be positive");
        }
        if (slotStepMinutes <= 0) {
            throw new IllegalArgumentException("slotStepMinutes must be positive");
        }

        int dayOfWeek = interviewerLocalDate.getDayOfWeek().getValue();
        List<PreferenceRule> dayRules = weeklyRules.stream()
                .filter(rule -> rule.getDayOfWeek() == dayOfWeek)
                .collect(Collectors.toList());

        List<TimeWindow> allowed = new ArrayList<>();
        List<TimeWindow> blocked = new ArrayList<>();

        for (PreferenceRule rule : dayRules) {
            TimeWindow window = new TimeWindow(rule.getStartMinute(), rule.getEndMinute());
            if (rule.getIsAvailable() == 1) {
                allowed.add(window);
            } else if (rule.getIsAvailable() == 0) {
                blocked.add(window);
            } else {
                throw new IllegalArgumentException("IS_AVAILABLE must be 0 or 1");
            }
        }

        if (allowed.isEmpty()) {
            return List.of(); // allowlist semantics: no AVAILABLE interval means no slots
        }

        allowed = mergeWindows(allowed);
        blocked = mergeWindows(blocked);
        List<TimeWindow> effectiveWindows = subtractBlocked(allowed, blocked);

        List<GeneratedInterviewSlot> result = new ArrayList<>();
        for (TimeWindow window : effectiveWindows) {
            int latestStart = window.endMinute - durationMinutes;
            for (int startMinute = window.startMinute;
                 startMinute <= latestStart;
                 startMinute += slotStepMinutes) {

                // Construct the start from local wall-clock time in the interviewer's zone.
                LocalTime localStartTime = LocalTime.ofSecondOfDay(startMinute * 60L);
                ZonedDateTime start = interviewerLocalDate.atTime(localStartTime).atZone(timeZone);
                ZonedDateTime end = start.plusMinutes(durationMinutes);
                result.add(new GeneratedInterviewSlot(start, end));
            }
        }

        result.sort(Comparator.comparing(GeneratedInterviewSlot::getStartDateTime));
        return result;
    }

    private List<TimeWindow> mergeWindows(List<TimeWindow> windows) {
        List<TimeWindow> sorted = new ArrayList<>(windows);
        sorted.sort(Comparator.comparingInt(window -> window.startMinute));
        List<TimeWindow> merged = new ArrayList<>();

        for (TimeWindow current : sorted) {
            if (merged.isEmpty()) {
                merged.add(current);
                continue;
            }
            int lastIndex = merged.size() - 1;
            TimeWindow previous = merged.get(lastIndex);
            if (current.startMinute <= previous.endMinute) {
                merged.set(lastIndex, new TimeWindow(previous.startMinute,
                        Math.max(previous.endMinute, current.endMinute)));
            } else {
                merged.add(current);
            }
        }
        return merged;
    }

    private List<TimeWindow> subtractBlocked(
            List<TimeWindow> allowedWindows, List<TimeWindow> blockedWindows) {
        List<TimeWindow> result = new ArrayList<>();

        for (TimeWindow allowed : allowedWindows) {
            int cursor = allowed.startMinute;
            for (TimeWindow blocked : blockedWindows) {
                if (blocked.endMinute <= cursor) continue;
                if (blocked.startMinute >= allowed.endMinute) break;

                if (blocked.startMinute > cursor) {
                    result.add(new TimeWindow(cursor,
                            Math.min(blocked.startMinute, allowed.endMinute)));
                }
                cursor = Math.max(cursor, blocked.endMinute);
                if (cursor >= allowed.endMinute) break;
            }
            if (cursor < allowed.endMinute) {
                result.add(new TimeWindow(cursor, allowed.endMinute));
            }
        }
        return result;
    }

    private static final class TimeWindow {
        private final int startMinute;
        private final int endMinute;

        private TimeWindow(int startMinute, int endMinute) {
            if (startMinute < 0 || startMinute >= 1440 || endMinute < 1 || endMinute > 1440
                    || endMinute <= startMinute) {
                throw new IllegalArgumentException("Invalid preference time window");
            }
            this.startMinute = startMinute;
            this.endMinute = endMinute;
        }
    }
}
