package com.example.personalizedavailability;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class PersonalizedAvailabilityApplication {
    public static void main(String[] args) {
        // Console-only application: run the demo and close the context on completion.
        try (ConfigurableApplicationContext ignored = SpringApplication.run(
                PersonalizedAvailabilityApplication.class, args)) {
            // CommandLineRunner executes during startup.
        }
    }
}
