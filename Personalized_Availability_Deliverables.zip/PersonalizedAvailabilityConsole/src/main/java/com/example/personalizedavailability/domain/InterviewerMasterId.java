package com.example.personalizedavailability.domain;

import java.io.Serializable;
import java.util.Objects;

public class InterviewerMasterId implements Serializable {
    private String interviewerSid;
    private String oracleCandId;

    public InterviewerMasterId() {
    }

    public InterviewerMasterId(String interviewerSid, String oracleCandId) {
        this.interviewerSid = interviewerSid;
        this.oracleCandId = oracleCandId;
    }

    public String getInterviewerSid() { return interviewerSid; }
    public void setInterviewerSid(String interviewerSid) { this.interviewerSid = interviewerSid; }
    public String getOracleCandId() { return oracleCandId; }
    public void setOracleCandId(String oracleCandId) { this.oracleCandId = oracleCandId; }

    @Override
    public boolean equals(Object other) {
        if (this == other) return true;
        if (!(other instanceof InterviewerMasterId that)) return false;
        return Objects.equals(interviewerSid, that.interviewerSid)
                && Objects.equals(oracleCandId, that.oracleCandId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(interviewerSid, oracleCandId);
    }
}
